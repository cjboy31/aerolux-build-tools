---
generated: true
model: claude-opus-5[1m]
generated_at: 2026-08-13T00:00:00+00:00
source_commit: c0e5ca5c55ff5ea6b210ac9418bac04728cc45e0
watched_paths_digest: 3952bb6ae44ce766550f6b8a475a4bfeacd527f7f82c2e8bb3067099f4e488a6
source_doc: docs/generated/design/name-resolution/overload-resolution.md
source_doc_digest: c83ec604440f6a3e9d71ebce10b680aba8f50363c6979cb0ff09972b10a420e1
warning: "Auto-generated. May drift from source. Do not edit by hand."
---

# Tests for design/name-resolution/overload-resolution

## Intent

This bundle exercises the overload-resolution algorithm described in
[`docs/generated/design/name-resolution/overload-resolution.md`](../../../../design/name-resolution/overload-resolution.md):
the builtin-operator fast path that bypasses the resolver entirely for numeric
scalar / vector / matrix operands, the `TryCheckOverloadCandidate` probe-phase
filter pipeline (arity, fixity, types and coercion, directions, constraints,
visibility), the candidate families the probe phase draws from, the `ForReal`
finalize phase and the focused generic-inference diagnostics it selects, the
`ConversionCost` ranking and the conversions that have no named cost level, the
`CompareOverloadCandidates` tie-breaker (status, cost, lookup-result kind,
implicit-conversion preference, specificity, scope distance, overload rank),
partial generic application, the general path taken by operators the fast path
declines, and the documented failure modes.

Coverage strategy: one row per documented claim, with positive claims observed
through `//TEST:INTERPRET(filecheck=CHECK):` (an integer tag echoed by `printf`
names the overload that fired, or an overload probe reveals the type an
expression was given) and failure-mode claims pinned with
`//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK):`. The conversion-cost table is treated as
an enumeration to expand rather than prose to summarize: each row that a pair of
user-written overloads can rank against a neighbouring row gets its own test,
and the rows that no user source can reach are classified in
`## Untested claims`. Boundary probes sit on the same anchor as their parent
claim: the adjacent pairs of the cost table (0 vs 400, 23 vs 400, 32 vs 400,
81 vs 400, 150 vs 400, 200 vs 300, 250 vs 400, 400 vs 450, 400 vs 500,
2 vs 10, 10 vs 410, 0 vs 30, 0 vs 400, 0 vs 500), the accumulated-cost sum past
the 900 implicit ceiling, the arity step's lower edge (defaults padding), upper
edge (too many) and unbounded edge (a variadic pack), and the 32-bit/64-bit and
signed/unsigned edges of the fast path's common-type rule.

Overload resolution is fixed at semantic check, so almost every test uses a
single target-independent directive. Two claims are exceptions and say so: the
GLSL-operator-scope carve-out uses an explicit `import glsl;` and therefore runs
as `COMPARE_COMPUTE -cpu`, and the parameter-group auto-dereference cost needs
a `ConstantBuffer` global that the interpreter cannot host, so it is observed
in emitted HLSL. One further test carries a `-std 2026` option because the
claim it pins is about a language-version boundary.

The source doc mixes user-observable rules with a description of the checker's
own structure (the `OverloadCandidate` fields, the filter-step function names,
the comparator's helper names). The enumeration below keeps the doc's own
wording for both, and the internal-structure statements that have no
`.slang`-visible consequence are classified in `## Untested claims` with reason
`internal-source-fact` rather than given tests.

## Claims

Enumerated per [`_claims.md` §1](../../../_meta/prompts/_claims.md), grouped by
the source doc's own headings. Claim IDs are referenced from the `Claim` cell of
the two tables below; every claim appears in exactly one of them.

### Concepts

1. `OverloadCandidate::Flavor` is one of `Func`, `Generic`, `UnspecializedGeneric`, `Expr`.
2. `OverloadCandidate::Status` progresses through `GenericArgumentInferenceFailed`, `Unchecked`, `ArityChecked`, `FixityChecked`, `TypeChecked`, `DirectionChecked`, `VisibilityChecked`, `Applicable`.
3. `OverloadCandidate::Flags` is a bitset holding only `IsPartiallyAppliedGeneric` today.
4. `explicitGenericArgCount` records how many leading ordinary generic arguments the caller supplied explicitly, starts at `-1`, and is handed to the generic constraint solver as a fixed prefix so a user-written argument is not overridden by a parameter default.
5. `GenericArgumentInferenceFailure::Kind` is one of `None`, `VariadicPackCountMismatch`, `GenericArityMismatch`, `OrdinaryGenericParamNotInferred`, `InterfaceConformanceNotSatisfied`, `GenericConstraintNotSatisfied`, `GenericParamUnificationConflict`.
6. `argMismatchArgIndex` / `argMismatchExpectedType` / `argMismatchActualType` record the first argument that failed to type-check, so a diagnostic can name the offending argument and both types rather than only the callee.
7. `OverloadResolveContext::Mode` is `JustTrying`, which silently rejects bad candidates, or `ForReal`, which emits a diagnostic for each rejection.
8. `ConversionCost` is an `unsigned int` whose `kConversionCost_*` levels sum across arguments.
9. `CoercionSite` is one of `General`, `Assignment`, `Argument`, `Return`, `Initializer`, `ExplicitCoercion`, and cost computation can vary per site.
10. Every `GenericArgumentInferenceFailure` payload is trivially copyable and the default constructor `memset`s the whole object, because candidates are copied inside standard-library algorithms.

### Probe phase: `TryCheckOverloadCandidate`

11. The probe pipeline runs arity, fixity, types, directions, constraints and visibility in that order and returns as soon as a step fails, leaving the candidate at the status of the last step it passed.
12. `TryCheckOverloadCandidateArity` accepts a call with fewer arguments than parameters when trailing defaults pad the count up to `allowed`.
13. A call below `required` is rejected, and in `ForReal` mode emits `Diagnostics::NotEnoughArguments`.
14. A call above `allowed` is rejected, and in `ForReal` mode emits `Diagnostics::TooManyArguments`.
15. An `allowed` of `-1` means unbounded, so a variadic callable accepts any count at or above `required`.
16. `TryCheckOverloadCandidateFixity` applies only to a `PrefixExpr` or `PostfixExpr` and requires the matching `PrefixModifier` / `PostfixModifier`, so `-x` does not bind to a postfix-only `operator-`; any other call form passes unconditionally.
17. `matchArgumentsToParams` pairs arguments with parameters and lets a brace initializer such as `f({1, 2})` be matched against a struct parameter instead of being rejected outright.
18. For `Flavor::Generic` the type step delegates to `TryCheckGenericOverloadCandidateTypes`, and when inference fails a separate `Flavor::UnspecializedGeneric` candidate carrying `Status::GenericArgumentInferenceFailed` is recorded so the failure can be diagnosed later.
19. In `ForReal` mode an explicit generic-argument list whose length falls outside the generic's allowed range gets `Diagnostics::GenericArgumentListArityMismatch`, and any other specialization failure gets `Diagnostics::CannotSpecializeGeneric`.
20. Only a too-short list reaches that arity diagnostic: `g<int, float, int>` on `int g<T, U>(T, U)` reports "too many arguments to call (got 3, expected 2)" from step 1 instead.
21. A too-short list lands on the generic-argument arity diagnostic only when the generic's inner declaration is not a `CallableDecl`; otherwise it becomes a partial generic application rather than an error.
22. For every argument the step calls `canCoerce(paramType, argType, arg.argExpr, &cost)` and accumulates the reported cost into `conversionCostSum`; when no coercion is possible the argument index and both types are recorded and the candidate is dropped.
23. When `context.disallowNestedConversions` is set the step demands `paramType->equals(argType)` instead of calling `canCoerce`, which is how the checker forbids stacking one user-defined conversion on top of another.
24. `TryCheckOverloadCandidateDirections` only checks the mutability of the implicit `this` parameter, rejecting a `[mutating]` method invoked on an immutable base with `Diagnostics::MutatingMethodOnImmutableValue`.
25. `TryCheckOverloadCandidateConstraints` validates `where`-clauses against the inferred substitutions and fills in generic arguments left to defaults, resolving them for an outermost generic through the `trySolveGenericArguments` fixpoint solver with the explicit ordinary prefix installed as fixed `CallerProvidedOrdinaryArg`s.
26. The solver's `solveCost` is deliberately not folded into `conversionCostSum`, because doing so would shift overload ranking and break ties that should stay ambiguous.
27. On solver failure the step falls through to the legacy per-constraint loop so `ForReal` mode can emit `Diagnostics::TypeArgumentDoesNotConformToInterface` for an unsatisfied conformance; nested generic applications keep the linear pass.
28. `TryCheckOverloadCandidateVisibility` delegates to `isDeclVisibleFromScope` and emits `Diagnostics::DeclIsNotVisible` in `ForReal` mode.
29. `TryCheckOverloadCandidateClassNewMatchUp` enforces the `new` / `class` pairing: a `NewExpr` whose candidate does not construct a `ClassDecl` gets `Diagnostics::NewCanOnlyBeUsedToInitializeAClass`, and a plain constructor call that does construct a class gets `Diagnostics::ClassCanOnlyBeInitializedWithNew`.
30. A candidate that survives every probe-phase step is tagged `Status::Applicable` with its total `conversionCostSum` populated.
31. `AddOverloadCandidateInner` removes every held entry the new candidate strictly beats, drops the new candidate when a held entry strictly beats it, and converts a unique best candidate into a two-element `bestCandidates` list on a tie.
32. Candidate tracking runs for every candidate, applicable or not, which is what lets the failure paths report the least-bad candidate rather than a bare "no overload".

### Probe phase: where candidates come from

33. `AddDeclRefOverloadCandidates` dispatches on the kind of declaration a `LookupResultItem` names: function aliases, callables, aggregate types, generics, typedefs, generic type parameters and function-valued parameters.
34. `AddFuncOverloadCandidate(LookupResultItem, DeclRef<CallableDecl>, ...)` contributes a single declared callable.
35. `AddCtorOverloadCandidate` contributes calls that go through a `ConstructorDecl`, with the result `Type` passed in.
36. `AddFuncOverloadCandidate(FuncType*, ...)` / `AddFuncExprOverloadCandidate` contribute first-class function values with `flavor == Expr`; a `ParamDecl` reaches that path only when its declared type is a `FuncType`, which source spells with `functype`.
37. `AddHigherOrderOverloadCandidates` contributes `__fwd_diff` / `__bwd_diff`-style operators that wrap a callee.
38. Each helper accepts a `baseCost` that `AddOverloadCandidate` adds to the candidate's accumulated cost; the ordinary lookup, function-value and higher-order entry points all pass `kConversionCost_None`, and today the only nontrivial `baseCost` is what `inferGenericArguments` reports.

### Finalize phase: `CompleteOverloadCandidate`

39. Once the probe phase finishes with exactly one best candidate, `CompleteOverloadCandidate` flips the mode to `ForReal` and re-runs the pipeline starting from `TryCheckOverloadCandidateClassNewMatchUp`, then arity, fixity, types, directions, constraints and visibility.
40. If the best candidate's status is `GenericArgumentInferenceFailed`, the recorded `genericInferenceFailure` selects a focused diagnostic, and only a `Kind::None` falls through to the blanket `Diagnostics::GenericArgumentInferenceFailed`.
41. Every inference-failure arm also emits a `Diagnostics::GenericSignatureTried` note rendered by `ASTPrinter::getDeclSignatureString`.
42. `Flavor::Func` and `Flavor::Generic` rebuild the callee with `ConstructLookupResultExpr`, which replays the item's breadcrumb chain; `Flavor::Func` then reuses `context.originalExpr` when it already is an `InvokeExpr`.
43. `Flavor::Generic` wraps the result in a `PartiallyAppliedGenericExpr` when the `IsPartiallyAppliedGeneric` flag is set, and otherwise builds a fully specialized generic decl-ref.
44. `Flavor::Expr` uses `candidate.exprVal` directly as the callee, with no `ConstructLookupResultExpr` step.
45. A `Flavor::UnspecializedGeneric` candidate never reaches the AST-construction switch, because its status is handled by the early error path.

### Conversion costs

46. Overload candidate probing computes each per-argument cost via `canCoerce` and accumulates the reported cost into the candidate's ranking sum.
47. An ambiguous conversion is deliberately reported as possible while probing and only fails when the checker asks for the coerced expression, at which point `Diagnostics::AmbiguousConversion` plus one `SeeDeclarationOf` note per tied initializer is emitted.
48. Two initializers with different parameter types can only tie at an explicit coercion site, because `_coerce` sets `disallowNestedConversions` everywhere else: `struct T { __init(int v) {} __init(uint v) {} }` with `T t = T(x)` on a `float` x is ambiguous.
49. Making the argument an `int` removes that ambiguity, because the exact match costs 0.
50. Writing `T t = x;` instead is an implicit site where neither initializer matches `float` exactly, so the failure is an ordinary type mismatch.
51. `canConvertImplicitly` allows anything cheaper than `kConversionCost_GeneralConversion` and rejects anything at or above it.
52. `kConversionCost_None` is 0 — identity.
53. `kConversionCost_GenericParamUpcast` is 1 — up-cast through a generic parameter.
54. `kConversionCost_LambdaToFunc` is 1 — lambda used where a `Func` value is expected.
55. `kConversionCost_UnconstraintGenericParam` is 20 — binding to an unconstrained generic parameter.
56. `kConversionCost_SizedArrayToUnsizedArray` is 30 — sized to unsized array.
57. `kConversionCost_MatrixLayout` is 5 — matrix layout adapter.
58. `kConversionCost_GetRef` is 5 — extracting a reference from a buffer-like type.
59. `kConversionCost_ImplicitDereference` is 10 — dereferencing a pointer-like value.
60. `kConversionCost_InRangeIntLitConversion` is 23 — int literal fits in target integer type.
61. `kConversionCost_InRangeIntLitSignedToUnsignedConversion` is 32 — signed literal to unsigned target.
62. `kConversionCost_InRangeIntLitUnsignedToSignedConversion` is 81 — unsigned literal to signed target.
63. `kConversionCost_MutablePtrToConstPtr` is 20 — mutable pointer to const pointer.
64. `kConversionCost_CastToInterface` is 50 — concrete type to conforming interface.
65. `kConversionCost_BoolToInt` is 120 — `bool` to int, deliberately cheaper to break ties.
66. `kConversionCost_RankPromotion` is 150 — lossless promotion to a higher rank within the same conversion kind.
67. `kConversionCost_NoneToOptional` is 150 — none to `Optional`.
68. `kConversionCost_ValToOptional` is 150 — `T` to `Optional`.
69. `kConversionCost_NullPtrToPtr` is 150 — nullptr to pointer.
70. `kConversionCost_PtrToVoidPtr` is 150 — `T*` to `void*`.
71. `kConversionCost_FailedOptionalConstraint` is 150 — optional constraint did not match.
72. `kConversionCost_UnsignedToSignedPromotion` is 200 — promoting unsigned to wider signed.
73. `kConversionCost_SameSizeUnsignedToSignedConversion` is 300 — same-size unsigned to signed.
74. `kConversionCost_SignedToUnsignedConversion` is 250 — signed to unsigned of same or greater size.
75. `kConversionCost_IntegerToFloatConversion` is 400 — int to float.
76. `kConversionCost_PtrToBool` is 400 — pointer to bool.
77. `kConversionCost_IntegerTruncate` is 450 — int to narrower int.
78. `kConversionCost_IntegerToHalfConversion` is 500 — int to half.
79. `kConversionCost_ParameterPack` is 500 — binding to a parameter pack.
80. `kConversionCost_Default` is 500 — user-defined conversion default.
81. `kConversionCost_GeneralConversion` is 900 — the implicit ceiling.
82. `kConversionCost_Explicit` is 90000 — explicit cast only, never accepted implicitly.
83. `kConversionCost_OneVectorToScalar` is 1, additive when downcasting a 1-vector to a scalar.
84. `kConversionCost_ScalarToVector` is 2, additive when promoting a scalar to a vector.
85. `kConversionCost_ScalarToMatrix` is 10, additive when promoting a scalar to a matrix.
86. `kConversionCost_ScalarIntegerToFloatMatrix` is 410, the sum of the int-to-float and scalar-to-matrix levels.
87. `kConversionCost_ScalarToCoopVector` is 1, additive when promoting a scalar to a cooperative vector.
88. `kConversionCost_LValueCast` is 800, additive when casting an l-value.
89. `kConversionCost_TypeCoercionConstraint` is 1000 — cost contributed by a type-coercion constraint.
90. `kConversionCost_TypeCoercionConstraintPlusScalarToVector` is 1002.
91. `kConversionCost_Impossible` is `0xFFFFFFFF` and is never summed, because the candidate is rejected before reaching ranking.

### Conversions that do not have their own cost level

92. `Optional<T>` to `Optional<U>` covariance recursively probes `T` to `U` and reports `innerCost + 1`, which keeps an exact match strictly cheaper than the covariant form.
93. A `ConstantBuffer<X>` / `ParameterBlock<X>` source is implicitly dereferenced to `X` at `kConversionCost_ImplicitDereference` before converting onward, so an overload on `ConstantBuffer<Foo>` still beats one on `Foo`.
94. Because that branch funnels all parameter-group coercion into the dereference path, a user-declared initializer that takes a parameter-group type is never considered by the conversion search.
95. `vector<T,4>` declares the `(vector<T,2>, T)` and `(T, vector<T,2>)` forms outright so overload resolution binds to them instead of promoting a scalar, and marks them `[deprecated]` and `[RemovedSince(2026, ...)]`.
96. Under the default language version `float4(f2, f)` still resolves to one of those forms, gets the legacy duplicate-the-scalar semantics, and reports the `[deprecated]` warning.
97. Compiling the module with language version 2026 or later turns the same call into an error instead, because `[RemovedSince]` fires and its message supersedes the deprecation one.
98. `createInvokeExprForExplicitCtor` type-checks the constructor against a temporary `DiagnosticSink` and forwards that sink's contents — including warning-severity output — to the real sink once it commits, skipping the forwarding when `outExpr == nullptr`.

### Short-circuiting a doomed conversion search

99. At a non-explicit coercion site `_coerce` returns failure immediately when `toType` is a scalar `BasicExpressionType` other than `bool` and `fromType` is a decl-ref to a `GenericTypeParamDeclBase`; `bool` and `DeclRefType` scalars such as `BFloat16` stay on the search path, and the guard changes no resolution outcome.

### Tie-breaking comparator

100. Step 1: a candidate with a higher `Status` wins, so an `Applicable` candidate is always preferred to an `ArityChecked` one.
101. Step 2: the lower `conversionCostSum` wins.
102. Step 3 `CompareLookupResultItems` prefers a concrete member over an interface requirement it satisfies.
103. Step 3 prefers a non-`extern` declaration over an `extern` one.
104. Step 3 prefers a non-extension declaration over an extension member, and an ordinary extension over a free-form one — an `extension` whose target type is a generic type parameter, spelled `extension<T : IFoo> T`.
105. Step 3 prefers any declaration over a module declaration and the more derived interface when both candidates are interface requirements, and returns "equal" outright when either candidate is a generic callable.
106. Step 4: if exactly one candidate is marked `ImplicitConversionModifier`, that one wins.
107. Step 5 `compareOverloadCandidateSpecificity` prefers the smaller `getSpecializedParamCount`, so a non-generic candidate beats a specialized generic one; variadicness and default-parameter counts are not consulted.
108. Step 6 `getExportRank` fires only when the left candidate carries `ExternModifier` and the right carries `HLSLExportModifier`, and then prefers the `extern` one.
109. Step 7: for non-generic flavors `getScopeRank` prefers the declaration at the shorter scope distance from the call site.
110. Step 8 `getOverloadRank` compares the `[OverloadRank(N)]` attribute — a declaration without it ranks 0 and the higher rank wins — and the attribute is declared `@internal`, with `core.meta.slang` / `hlsl.meta.slang` its only users in the tree.
111. If every step returns zero the candidates are considered equally good and an ambiguous-overload diagnostic follows.

### Relationship to lookup

112. Lookup does not deduplicate at the `LookupResult` level: a name found along several paths yields several `LookupResultItem`s and collapsing them is `CompareLookupResultItems`' job.
113. `context.bestCandidates` can hold the same declaration more than once, which is why the "no applicable overload" reporting path dedups by rendered signature string before printing notes.

### Partial generic application

114. When the call supplies arguments that pin some but not all of a generic's parameters, the candidate is flagged `IsPartiallyAppliedGeneric` and `CompleteOverloadCandidate` wraps the result in a `PartiallyAppliedGenericExpr`.
115. `TryCheckOverloadCandidateConstraints` short-circuits on that flag, because a later pass of overload resolution supplies the information constraint checking still needs.
116. A `PartiallyAppliedGenericExpr` carries `baseGenericDeclRef` plus `providedOrdinaryArgs`; witness arguments are deliberately not stored on the node and are formed later.
117. Using the partial as the callee of a later invocation hands both to `addOverloadCandidatesForCallToGeneric`, so call-site inference solves the remaining ordinary arguments and all witness arguments together.

### Operator overloading

118. The parser turns `a + b` into an `InvokeExpr` whose `functionExpr` is a `VarExpr` naming the operator.

### The builtin-operator fast path

119. `visitInvokeExpr` tries `convertToLogicOperatorExpr` and then `convertToBuiltinArithmeticOp` before collecting any candidates, and when the latter succeeds the expression is replaced by a fully checked `BuiltinOperatorExpr` and overload resolution never runs for it.
120. `BuiltinOperatorExpr` carries only a `BuiltinOperationKind` and its 1 or 2 operands, with the name-to-kind mapping performed once at creation and the `arity` argument distinguishing prefix `-` (`Neg`) from binary `-` (`Sub`).
121. The recognized set is `+ - * / %`, `== != < > <= >=`, `& \| ^ << >>`, and unary `- ! ~` on builtin integer / floating-point / bool scalars, vectors and matrices.
122. `Conditional`, `And` and `Or` are never produced by the fast path but exist so a resolved call on them can still fold to a compile-time constant, for example `cond ? N : M` in an array size.
123. `getBuiltinArithmeticCommonType` applies the usual arithmetic conversions, so float beats int.
124. Among integers the larger size wins.
125. On an integer size tie the unsigned type wins.
126. `coerceOperandsOfBuiltinBinaryExpr` coerces each operand to its own shape with the common element base, so a `vector * scalar` stays a two-shape operation.
127. The result type is the operand type for arithmetic and bitwise ops, and the same-shape `bool` type for comparisons.
128. The fast path declines the short-circuiting `&&` / `\|\|`, which `convertToLogicOperatorExpr` has already handled.
129. The fast path declines user-defined operand types and mixed shapes that are not broadcast-compatible.
130. The fast path declines mixed-type shift operands, because `a << b` keeps the type of `a` and converts the shift amount independently.
131. In GLSL operator scope only, the fast path declines matrix operands and vector equality; `isGLSLOperatorScope` is true for GLSL source or when non-GLSL source explicitly imports the `glsl` module.
132. A bitwise or shift operator with a builtin floating-point operand is diagnosed by the fast path with `Diagnostics::BitwiseOperatorRequiresIntegerOperands`.
133. Unary `~` on a builtin floating-point operand is diagnosed the same way.
134. There is no operator-resolution cache at `source_commit`: `TypeCheckingCache` holds only `conversionCostCache`, which `canCoerce` consults and fills for scalar and vector operand pairs.
135. The `ResolvedOperatorOverload` struct is a declared-but-unreferenced artifact of the removed cache and must not be read as documentation of current behavior.

### The general path

136. Operators the fast path declines reach overload resolution through the same machinery, with the candidate set collected by ordinary lookup of the operator-keyed `Name` in the call site's scope chain.
137. `TryCheckOverloadCandidateFixity` rejects a candidate whose `prefix` / `postfix` modifiers do not match the call form, emitting `Diagnostics::ExpectedPrefixOperator` / `Diagnostics::ExpectedPostfixOperator`.
138. The operand types play no part in finding the candidates: there is no member lookup on the left operand's type and no argument-dependent lookup.
139. A user-declared infix, prefix or postfix operator has to be a free function in scope at the call site; an `operator+` declared inside `struct V` or in an `extension V` is not a name an outside call site can see, and `v1 + v2` there reports no applicable overload.
140. A non-static member form could not match anyway, because the implicit `this` is not one of the call's arguments and arity weighs two operands against a declared parameter list of one.
141. `operator()` is resolved by member lookup on the callee's type when the callee is a value of `DeclRefType`, keeping the implicit `this` through a `Breadcrumb::Kind::This` step that `ConstructLookupResultExpr` replays.
142. `visitIndexExpr` looks `__subscript` up the same way for `a[i]`.
143. A `[mutating]` member operator applied to an immutable base is rejected by `TryCheckOverloadCandidateDirections`, which tests `context.baseExpr->type.isLeftValue`.

### Edge cases and failure modes

144. Two `Applicable` candidates with identical cost, specificity and scope produce `Diagnostics::AmbiguousOverloadForNameWithArgs`, or `AmbiguousOverloadWithArgs` when the callee name is unknown.
145. Each tied candidate is listed as a `Candidate` note, capped at 10 with a trailing `Diagnostics::MoreOverloadCandidates` note for the remainder.
146. When a single non-applicable candidate scores best, the resolver re-runs the pipeline on it in `ForReal` mode so the user sees a per-argument coercion failure rather than a generic "no overload" message.
147. When several non-applicable candidates tie for best, the resolver emits `Diagnostics::NoApplicableOverloadForNameWithArgs` directly, without calling `CompleteOverloadCandidate`.
148. Each candidate note under that error is followed by `Diagnostics::OverloadCandidateArgumentTypeMismatch` — "argument N does not match: expected 'X', got 'Y'".
149. Candidates in that report are sorted by `status` with the declaration's source location as a deterministic tie-breaker, deduped by rendered signature string, and the trailing "N more" count covers unique candidates only.
150. `VariadicPackCountMismatch` maps to `Diagnostics::VariadicPackCountDoesNotMatch`.
151. `GenericArityMismatch` maps to `Diagnostics::GenericSpecializationArityMismatch`.
152. `OrdinaryGenericParamNotInferred` maps to `Diagnostics::GenericParameterCouldNotBeInferred`, naming the parameter that stayed undetermined.
153. `GenericConstraintNotSatisfied` maps to `Diagnostics::GenericArgumentDoesNotSatisfyConstraint` plus a `SeeGenericConstraintDeclaration` note, and is the fallback for every witness-solver constraint kind except interface conformance — equality (`where T == X`), type coercion (`where U(T)`), non-empty pack (`where nonempty(P)`).
154. `GenericParamUnificationConflict` maps to `Diagnostics::GenericParameterUnificationConflict`, reporting both conflicting deductions.
155. `InterfaceConformanceNotSatisfied` maps to `Diagnostics::TypeArgumentDoesNotConformToInterface`.
156. `None` falls back to `Diagnostics::GenericArgumentInferenceFailed`.
157. A pack argument whose length violates a `countof` constraint is solved as part of generic-argument inference, so the mismatch is reported through the `VariadicPackCountMismatch` arm rather than as a separate arity error.
158. A candidate hidden by visibility is silently dropped in `JustTrying` and emits `Diagnostics::DeclIsNotVisible` in `ForReal`; when no candidate applies and some were invisible, the reporting path calls them out with `Diagnostics::InvisibleOverloadCandidate`.
159. Probing applies no per-argument cost ceiling and the accumulated sum has no ceiling either; the candidate is dropped only when `canCoerce` reports that no coercion exists, and `canConvertImplicitly` is never called from `slang-check-overload.cpp`.
160. Scope-distance and overload-rank tie-breaking are skipped when at least one candidate is `Generic` or `UnspecializedGeneric`; cost and specificity still apply, and a remaining tie is reported ambiguous.
161. `float << int` or `~1.0f` are diagnosed as `Diagnostics::BitwiseOperatorRequiresIntegerOperands` by `convertToBuiltinArithmeticOp` rather than surfacing as a "no overload for `operator<<`" message.
162. `[NoDiscard]` is checked after a call has already been resolved, never makes a candidate more or less viable, and contributes no conversion cost.
163. Leaving a `PartiallyAppliedGenericExpr` residual unresolved is a correctness-invariant violation, not a feature.

## Functional coverage

| Claim | Intent | Anchor | Tests |
| --- | --- | --- | --- |
| C46, C52, C75, C101: An identity match (kConversionCost_None, 0) beats kConversionCost_IntegerToFloatConversion (400) when both overloads accept an int argument. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-exact-match-beats-int-to-float.slang`](cost-exact-match-beats-int-to-float.slang) |
| C49: An int argument to the same two-initializer type removes the ambiguity because the exact match costs 0. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`conversion-exact-int-argument-removes-ambiguity.slang`](conversion-exact-int-argument-removes-ambiguity.slang) |
| C50: At an implicit site disallowNestedConversions demands an exact parameter match, so the same two-initializer type reports an ordinary type mismatch rather than an ambiguity. | negative | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`conversion-implicit-site-is-plain-type-mismatch-diagnostic.slang`](conversion-implicit-site-is-plain-type-mismatch-diagnostic.slang) |
| C81, C159: Probing applies no ceiling to conversionCostSum, so a candidate whose per-argument costs sum past kConversionCost_GeneralConversion (900) is still applicable. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-accumulated-sum-has-no-ceiling.slang`](cost-accumulated-sum-has-no-ceiling.slang) |
| C47, C48: Two initializers whose parameter types tie for cheapest are both reported as possible while probing and fail with ambiguous conversion when the coerced expression is requested. | negative | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`conversion-ambiguous-two-initializers-diagnostic.slang`](conversion-ambiguous-two-initializers-diagnostic.slang) |
| C65: kConversionCost_BoolToInt (120) is cheaper than kConversionCost_IntegerToFloatConversion (400), so a bool argument selects the int overload. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-bool-to-int-beats-int-to-float.slang`](cost-bool-to-int-beats-int-to-float.slang) |
| C82, C146: kConversionCost_Explicit (90000) is never accepted implicitly, so a non-implicit __init is rejected as an argument conversion and only offered as an explicit one. | negative | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-explicit-only-conversion-rejected-implicitly-diagnostic.slang`](cost-explicit-only-conversion-rejected-implicitly-diagnostic.slang) |
| C60: kConversionCost_InRangeIntLitConversion (23) is cheaper than kConversionCost_IntegerToFloatConversion (400), so an in-range integer literal selects the int16_t overload. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-int-literal-in-range-beats-int-to-float.slang`](cost-int-literal-in-range-beats-int-to-float.slang) |
| C61: kConversionCost_InRangeIntLitSignedToUnsignedConversion (32) is cheaper than kConversionCost_IntegerToFloatConversion (400), so an in-range integer literal selects the uint overload. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-int-literal-to-unsigned-beats-int-to-float.slang`](cost-int-literal-to-unsigned-beats-int-to-float.slang) |
| C62: kConversionCost_InRangeIntLitUnsignedToSignedConversion (81) is cheaper than kConversionCost_IntegerToFloatConversion (400), so an unsigned literal selects the int overload. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-uint-literal-to-signed-beats-int-to-float.slang`](cost-uint-literal-to-signed-beats-int-to-float.slang) |
| C78: kConversionCost_IntegerToFloatConversion (400) is cheaper than kConversionCost_IntegerToHalfConversion (500), so an int variable prefers the float overload over the half one. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-int-to-float-beats-int-to-half.slang`](cost-int-to-float-beats-int-to-half.slang) |
| C77: kConversionCost_IntegerToFloatConversion (400) is cheaper than kConversionCost_IntegerTruncate (450), so an int argument prefers a float parameter over a narrower integer one. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-int-to-float-beats-integer-truncate.slang`](cost-int-to-float-beats-integer-truncate.slang) |
| C54: kConversionCost_LambdaToFunc (1) makes a lambda bind to a functype parameter, so the lambda body is the callee the parameter invokes. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-lambda-to-func-binds-functype-parameter.slang`](cost-lambda-to-func-binds-functype-parameter.slang) |
| C67: kConversionCost_NoneToOptional (150) lets none reach an Optional parameter, so the Optional overload is the one the resolver selects. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-none-to-optional-selects-optional-overload.slang`](cost-none-to-optional-selects-optional-overload.slang) |
| C69: kConversionCost_NullPtrToPtr (150) makes nullptr reach a Ptr parameter, selecting the pointer overload over an int one. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-null-pointer-to-pointer-parameter.slang`](cost-null-pointer-to-pointer-parameter.slang) |
| C83: kConversionCost_OneVectorToScalar (1) makes a one-element vector argument reach a scalar parameter implicitly. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-one-vector-to-scalar-downcast-applies.slang`](cost-one-vector-to-scalar-downcast-applies.slang) |
| C79: kConversionCost_ParameterPack (500) makes binding to a variadic pack lose to an exact non-pack match of cost 0. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-parameter-pack-loses-to-exact-match.slang`](cost-parameter-pack-loses-to-exact-match.slang) |
| C76: kConversionCost_PtrToBool (400) makes a pointer argument lose to an exact Ptr parameter while still being convertible to bool. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-pointer-to-bool-loses-to-exact-pointer.slang`](cost-pointer-to-bool-loses-to-exact-pointer.slang) |
| C66: kConversionCost_RankPromotion (150) is cheaper than kConversionCost_IntegerToFloatConversion (400), so widening int to int64_t beats converting it to float. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-rank-promotion-beats-int-to-float.slang`](cost-rank-promotion-beats-int-to-float.slang) |
| C86: kConversionCost_ScalarIntegerToFloatMatrix (410) is the sum of the int-to-float and scalar-to-matrix levels, so an int scalar prefers an int2x2 parameter (10) over a float2x2 one. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-scalar-integer-to-float-matrix-sum.slang`](cost-scalar-integer-to-float-matrix-sum.slang) |
| C85: kConversionCost_ScalarToVector (2) is cheaper than kConversionCost_ScalarToMatrix (10), so a float scalar prefers the float2 overload over the float2x2 one. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-scalar-to-vector-beats-scalar-to-matrix.slang`](cost-scalar-to-vector-beats-scalar-to-matrix.slang) |
| C84: kConversionCost_ScalarToVector is additive on top of the element conversion, so an exact scalar match beats promoting the same argument to a vector. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-scalar-to-vector-promotion-loses-to-exact.slang`](cost-scalar-to-vector-promotion-loses-to-exact.slang) |
| C74: kConversionCost_SignedToUnsignedConversion (250) is cheaper than kConversionCost_IntegerToFloatConversion (400), so an int variable selects the uint overload. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-signed-to-unsigned-beats-int-to-float.slang`](cost-signed-to-unsigned-beats-int-to-float.slang) |
| C56: kConversionCost_SizedArrayToUnsizedArray (30) makes an unsized-array parameter lose to an exactly-sized one for a fixed-size array argument. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-sized-array-to-unsized-array-loses-to-exact.slang`](cost-sized-array-to-unsized-array-loses-to-exact.slang) |
| C55, C64: kConversionCost_UnconstraintGenericParam (20) is cheaper than kConversionCost_CastToInterface (50), so the cost step selects the generic candidate before the specificity step could prefer the non-generic one. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-unconstrained-generic-param-beats-cast-to-interface.slang`](cost-unconstrained-generic-param-beats-cast-to-interface.slang) |
| C72, C73: kConversionCost_UnsignedToSignedPromotion (200) is cheaper than kConversionCost_SameSizeUnsignedToSignedConversion (300), so a uint argument prefers int64_t over int. | boundary | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-unsigned-to-wider-signed-beats-same-size-signed.slang`](cost-unsigned-to-wider-signed-beats-same-size-signed.slang) |
| C68: kConversionCost_ValToOptional (150) is cheaper than kConversionCost_IntegerToFloatConversion (400), so an int argument selects the Optional<int> overload. | functional | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | [`cost-val-to-optional-beats-int-to-float.slang`](cost-val-to-optional-beats-int-to-float.slang) |
| C59, C93: A ConstantBuffer source is implicitly dereferenced at kConversionCost_ImplicitDereference (10) before converting onward, so an overload taking ConstantBuffer<Foo> beats one taking Foo. | functional | [#conversions-that-do-not-have-their-own-cost-level](../../../../design/name-resolution/overload-resolution.md#conversions-that-do-not-have-their-own-cost-level) | [`parameter-group-auto-dereference-prefers-constant-buffer.slang`](parameter-group-auto-dereference-prefers-constant-buffer.slang) |
| C97: Compiling with language version 2026 turns the same float4(f2, f) call into an error because [RemovedSince] supersedes the deprecation message. | negative | [#conversions-that-do-not-have-their-own-cost-level](../../../../design/name-resolution/overload-resolution.md#conversions-that-do-not-have-their-own-cost-level) | [`vector4-from-vector2-and-scalar-removed-since-2026-diagnostic.slang`](vector4-from-vector2-and-scalar-removed-since-2026-diagnostic.slang) |
| C92: Optional<T> to Optional<U> covariance recursively probes the inner conversion, so an Optional<int> argument reaches an Optional<float> parameter. | functional | [#conversions-that-do-not-have-their-own-cost-level](../../../../design/name-resolution/overload-resolution.md#conversions-that-do-not-have-their-own-cost-level) | [`optional-covariance-permits-inner-conversion.slang`](optional-covariance-permits-inner-conversion.slang) |
| C96, C98: The (vector<T,2>, T) initializer overload resolution binds to is marked [deprecated], so a float4(f2, f) call reports the deprecation warning. | negative | [#conversions-that-do-not-have-their-own-cost-level](../../../../design/name-resolution/overload-resolution.md#conversions-that-do-not-have-their-own-cost-level) | [`vector4-from-vector2-and-scalar-deprecated-diagnostic.slang`](vector4-from-vector2-and-scalar-deprecated-diagnostic.slang) |
| C95, C96: Under the default language version float4(f2, f) still resolves to the declared (vector<T,2>, T) initializer and duplicates the scalar into the last two components. | functional | [#conversions-that-do-not-have-their-own-cost-level](../../../../design/name-resolution/overload-resolution.md#conversions-that-do-not-have-their-own-cost-level) | [`vector4-from-vector2-and-scalar-duplicates-scalar.slang`](vector4-from-vector2-and-scalar-duplicates-scalar.slang) |
| C153: An unsatisfied non-empty-pack constraint (where nonempty(T)) is reported as generic-constraint-not-satisfied naming the constraint. | negative | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | [`constraints-nonempty-pack-not-satisfied-diagnostic.slang`](constraints-nonempty-pack-not-satisfied-diagnostic.slang) |
| C153: An unsatisfied type-equality constraint (where T == int) is reported as generic-constraint-not-satisfied naming the constraint. | negative | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | [`constraints-type-equality-not-satisfied-diagnostic.slang`](constraints-type-equality-not-satisfied-diagnostic.slang) |
| C107: Default-parameter counts are not consulted by the specificity step, so an overload pair that differs only by a trailing defaulted parameter ties and is reported ambiguous. | negative | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | [`edge-ambiguous-default-parameter-tie-diagnostic.slang`](edge-ambiguous-default-parameter-tie-diagnostic.slang) |
| C111, C144: Two Applicable candidates that tie on every comparator step are both kept in bestCandidates and reported as an ambiguous call. | negative | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | [`edge-ambiguous-equal-cost-candidates-diagnostic.slang`](edge-ambiguous-equal-cost-candidates-diagnostic.slang) |
| C6, C148: Under a no-applicable-overload error each candidate note is followed by an argument-N-does-not-match note built from the recorded mismatch index and both types. | negative | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | [`edge-no-applicable-names-offending-argument-index.slang`](edge-no-applicable-names-offending-argument-index.slang) |
| C32, C91, C147: When several non-applicable candidates tie for best the resolver emits no-applicable-overload-for-name-with-args directly, listing the argument types it could not match. | negative | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | [`edge-no-applicable-overload-diagnostic.slang`](edge-no-applicable-overload-diagnostic.slang) |
| C162: [NoDiscard] is checked only after a call has been resolved, so it contributes no conversion cost and does not make a candidate more or less viable. | functional | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | [`edge-nodiscard-does-not-affect-resolution.slang`](edge-nodiscard-does-not-affect-resolution.slang) |
| C150, C157: A pack argument whose length violates a countof constraint fails as VariadicPackCountMismatch during inference and is reported with the expected and actual element counts. | negative | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | [`finalize-inference-failure-pack-count-mismatch-diagnostic.slang`](finalize-inference-failure-pack-count-mismatch-diagnostic.slang) |
| C42: CompleteOverloadCandidate rebuilds the callee by replaying the lookup item's breadcrumb chain, so an interface-bounded generic call dispatches to the conforming type's implementation. | functional | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | [`finalize-breadcrumb-replay-dispatches-through-witness.slang`](finalize-breadcrumb-replay-dispatches-through-witness.slang) |
| C29: TryCheckOverloadCandidateClassNewMatchUp rejects a plain constructor call whose candidate constructs a class, which must be initialized with new. | negative | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | [`finalize-class-without-new-diagnostic.slang`](finalize-class-without-new-diagnostic.slang) |
| C29: TryCheckOverloadCandidateClassNewMatchUp runs only in the finalize re-check and rejects a new expression whose candidate does not construct a class. | negative | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | [`finalize-new-on-non-class-diagnostic.slang`](finalize-new-on-non-class-diagnostic.slang) |
| C18, C40, C152: When a candidate ends at GenericArgumentInferenceFailed with OrdinaryGenericParamNotInferred, CompleteOverloadCandidate emits the focused could-not-infer-parameter diagnostic naming the parameter. | negative | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | [`finalize-inference-failure-param-not-inferred-diagnostic.slang`](finalize-inference-failure-param-not-inferred-diagnostic.slang) |
| C154: When generic inference deduces two conflicting bindings for one parameter, the GenericParamUnificationConflict arm reports both conflicting deductions. | negative | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | [`finalize-inference-failure-unification-conflict-diagnostic.slang`](finalize-inference-failure-unification-conflict-diagnostic.slang) |
| C156: When no focused reason is recorded the inference failure falls through to the blanket could-not-specialize-generic diagnostic naming the argument types. | negative | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | [`finalize-inference-failure-blanket-fallback-diagnostic.slang`](finalize-inference-failure-blanket-fallback-diagnostic.slang) |
| C43: A generic candidate whose parameters are all pinned by the call arguments is fully specialized rather than left partially applied. | functional | [#partial-generic-application](../../../../design/name-resolution/overload-resolution.md#partial-generic-application) | [`partial-generic-inferred-from-argument.slang`](partial-generic-inferred-from-argument.slang) |
| C4, C114, C117: An explicit ordinary generic-argument prefix pins the leading parameters while call-site inference solves the remaining ones together. | functional | [#partial-generic-application](../../../../design/name-resolution/overload-resolution.md#partial-generic-application) | [`partial-generic-explicit-prefix-then-inferred-rest.slang`](partial-generic-explicit-prefix-then-inferred-rest.slang) |
| C11, C30: A candidate that survives arity, fixity, type, direction, constraint and visibility filtering is tagged Applicable and is the call the resolver builds. | functional | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`probe-applicable-survives-every-filter-step.slang`](probe-applicable-survives-every-filter-step.slang) |
| C19, C21: A too-short explicit generic-argument list on a generic whose inner declaration is not a callable cannot be partially applied and reaches the generic-argument-list arity diagnostic. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`generic-arg-list-too-short-on-generic-struct-diagnostic.slang`](generic-arg-list-too-short-on-generic-struct-diagnostic.slang) |
| C15: An allowed count of -1 makes a variadic callable accept any argument count at or above required, so zero, one and many arguments all pass the arity step. | boundary | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`arity-variadic-accepts-any-count-above-required.slang`](arity-variadic-accepts-any-count-above-required.slang) |
| C20: An explicit generic-argument list with too many arguments is rejected by the arity step with too-many-arguments rather than by the generic-argument-list arity diagnostic. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`generic-explicit-arg-list-too-many-reports-too-many-arguments.slang`](generic-explicit-arg-list-too-many-reports-too-many-arguments.slang) |
| C12: TryCheckOverloadCandidateArity accepts a call with fewer arguments than parameters when trailing defaults pad the count up to allowed. | boundary | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`arity-trailing-defaults-pad-to-allowed.slang`](arity-trailing-defaults-pad-to-allowed.slang) |
| C14, C39: TryCheckOverloadCandidateArity rejects a call above the allowed argument count and the finalize re-check emits too-many-arguments. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`arity-too-many-arguments-diagnostic.slang`](arity-too-many-arguments-diagnostic.slang) |
| C13: TryCheckOverloadCandidateArity rejects a call below the required argument count and the finalize re-check emits not-enough-arguments. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`arity-too-few-arguments-diagnostic.slang`](arity-too-few-arguments-diagnostic.slang) |
| C27, C155: TryCheckOverloadCandidateConstraints rejects a generic candidate whose inferred type argument does not satisfy the declared interface conformance. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`constraints-type-argument-does-not-conform-diagnostic.slang`](constraints-type-argument-does-not-conform-diagnostic.slang) |
| C24: TryCheckOverloadCandidateDirections checks the mutability of the implicit this parameter and rejects a [mutating] method invoked on an immutable base. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`directions-mutating-method-on-immutable-value-diagnostic.slang`](directions-mutating-method-on-immutable-value-diagnostic.slang) |
| C16, C137: TryCheckOverloadCandidateFixity rejects a postfix-only operator overload used in prefix position, so -x does not bind to a __postfix operator-. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`fixity-prefix-use-of-postfix-only-operator-diagnostic.slang`](fixity-prefix-use-of-postfix-only-operator-diagnostic.slang) |
| C28, C158: TryCheckOverloadCandidateVisibility drops a candidate that isDeclVisibleFromScope rejects, and the finalize re-check emits decl-is-not-visible. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`visibility-private-member-not-visible-diagnostic.slang`](visibility-private-member-not-visible-diagnostic.slang) |
| C22, C80: canCoerce accepts a single user-declared implicit-conversion initializer, so an A argument reaches a B parameter and the candidate becomes applicable. | functional | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`types-implicit-conversion-initializer-applies.slang`](types-implicit-conversion-initializer-applies.slang) |
| C23: disallowNestedConversions stops one user-defined conversion from being stacked on top of another, so an A argument does not reach a C parameter through B. | negative | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`types-nested-user-conversions-rejected-diagnostic.slang`](types-nested-user-conversions-rejected-diagnostic.slang) |
| C17: matchArgumentsToParams lets a brace initializer argument be matched against a struct parameter instead of being rejected outright. | functional | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | [`types-brace-initializer-matched-to-struct-parameter.slang`](types-brace-initializer-matched-to-struct-parameter.slang) |
| C36, C44: A parameter whose declared type is spelled with functype takes the function-value candidate path, so an ordinary function name passed as that argument becomes the callee. | functional | [#probe-phase-where-candidates-come-from](../../../../design/name-resolution/overload-resolution.md#probe-phase-where-candidates-come-from) | [`candidate-from-functype-parameter.slang`](candidate-from-functype-parameter.slang) |
| C35: AddCtorOverloadCandidate contributes a type's constructor declarations as candidates, and the resolver picks among them on argument types like free functions. | functional | [#probe-phase-where-candidates-come-from](../../../../design/name-resolution/overload-resolution.md#probe-phase-where-candidates-come-from) | [`candidate-from-constructor-decl.slang`](candidate-from-constructor-decl.slang) |
| C33: AddDeclRefOverloadCandidates dispatches through a typedef to the aggregate type it names, so calling the alias enumerates the underlying type's constructors. | functional | [#probe-phase-where-candidates-come-from](../../../../design/name-resolution/overload-resolution.md#probe-phase-where-candidates-come-from) | [`candidate-from-typealias-of-aggregate-type.slang`](candidate-from-typealias-of-aggregate-type.slang) |
| C34: AddDeclRefOverloadCandidates turns each member of a lookup result into a candidate, so a member call resolves to the same-name method whose parameter list matches. | functional | [#probe-phase-where-candidates-come-from](../../../../design/name-resolution/overload-resolution.md#probe-phase-where-candidates-come-from) | [`candidate-from-member-method.slang`](candidate-from-member-method.slang) |
| C37: AddHigherOrderOverloadCandidates contributes candidates for operators such as __fwd_diff that wrap a callee, so the wrapped function resolves and is applied. | functional | [#probe-phase-where-candidates-come-from](../../../../design/name-resolution/overload-resolution.md#probe-phase-where-candidates-come-from) | [`candidate-from-higher-order-differentiation-operator.slang`](candidate-from-higher-order-differentiation-operator.slang) |
| C127: A comparison handled by the fast path produces the same-shape bool type, so int3 == int3 has type vector<bool,3>. | functional | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-comparison-result-is-same-shape-bool.slang`](fastpath-comparison-result-is-same-shape-bool.slang) |
| C130: A mixed-type shift is declined by the fast path and resolved by the general path, which keeps the type of the left operand rather than a common type. | boundary | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-mixed-type-shift-falls-to-general-path.slang`](fastpath-mixed-type-shift-falls-to-general-path.slang) |
| C132, C161: A shift operator with a builtin floating-point operand is diagnosed by the fast path itself with bitwise-operator-requires-integer-operands rather than falling through to a no-overload message. | negative | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-shift-with-float-operand-diagnostic.slang`](fastpath-shift-with-float-operand-diagnostic.slang) |
| C119, C121: A user-declared operator+(int, int) never fires on builtin int operands because convertToBuiltinArithmeticOp rewrites the expression before any candidate is collected. | functional | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-user-operator-on-builtin-operands-bypassed.slang`](fastpath-user-operator-on-builtin-operands-bypassed.slang) |
| C124: Among integer operands the larger size wins, so an int + int64_t expression has type int64_t. | boundary | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-common-type-larger-integer-wins.slang`](fastpath-common-type-larger-integer-wins.slang) |
| C131: In GLSL operator scope the fast path declines matrix operands, so mat * mat resolves through the glsl module's overload to an algebraic matrix product. | boundary | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-declines-in-glsl-operator-scope.slang`](fastpath-declines-in-glsl-operator-scope.slang) |
| C125: On an integer size tie the unsigned type wins, so an int + uint expression has type uint. | boundary | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-common-type-unsigned-wins-on-size-tie.slang`](fastpath-common-type-unsigned-wins-on-size-tie.slang) |
| C122: The Conditional operation kind lets a resolved ?: expression fold to a compile-time constant usable as an array size. | functional | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-conditional-folds-in-array-size.slang`](fastpath-conditional-folds-in-array-size.slang) |
| C133: Unary ~ applied to a builtin floating-point operand is diagnosed by the fast path with bitwise-operator-requires-integer-operands. | negative | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-unary-complement-on-float-diagnostic.slang`](fastpath-unary-complement-on-float-diagnostic.slang) |
| C126: coerceOperandsOfBuiltinBinaryExpr coerces each operand to its own shape, so float3 * float stays a vector-times-scalar operation whose result is float3. | functional | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-vector-times-scalar-keeps-vector-shape.slang`](fastpath-vector-times-scalar-keeps-vector-shape.slang) |
| C123: getBuiltinArithmeticCommonType makes float beat int, so an int + float expression has type float. | functional | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | [`fastpath-common-type-float-beats-int.slang`](fastpath-common-type-float-beats-int.slang) |
| C139, C140: A user-declared operator+ written as a member of a struct is not a name the call site can see, so v1 + v2 reports no applicable overload. | negative | [#the-general-path](../../../../design/name-resolution/overload-resolution.md#the-general-path) | [`operator-member-declaration-not-in-scope-diagnostic.slang`](operator-member-declaration-not-in-scope-diagnostic.slang) |
| C129, C136: An operator whose operands are user-defined types is declined by the fast path and resolved by the general pipeline, so a user-declared operator+ on a struct fires. | functional | [#the-general-path](../../../../design/name-resolution/overload-resolution.md#the-general-path) | [`operator-overload-on-user-struct-uses-general-path.slang`](operator-overload-on-user-struct-uses-general-path.slang) |
| C138: Two user-declared operator+ overloads on different struct types are separate candidates in one operator-keyed candidate set and each dispatches on its own operand types. | functional | [#the-general-path](../../../../design/name-resolution/overload-resolution.md#the-general-path) | [`operator-overload-distinct-struct-types-each-dispatch.slang`](operator-overload-distinct-struct-types-each-dispatch.slang) |
| C142: __subscript is resolved by member lookup on the indexed value's type, so a[i] dispatches to the type's subscript getter with the implicit this. | functional | [#the-general-path](../../../../design/name-resolution/overload-resolution.md#the-general-path) | [`subscript-resolves-through-member-lookup.slang`](subscript-resolves-through-member-lookup.slang) |
| C141: operator() is resolved by member lookup on the callee's type, so calling a struct value like a function dispatches to its operator() member. | functional | [#the-general-path](../../../../design/name-resolution/overload-resolution.md#the-general-path) | [`operator-call-resolves-through-member-lookup.slang`](operator-call-resolves-through-member-lookup.slang) |
| C102: CompareLookupResultItems prefers a concrete member over the interface requirement it satisfies, so a conforming type's override wins over the interface default. | functional | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | [`tiebreak-concrete-member-beats-interface-requirement.slang`](tiebreak-concrete-member-beats-interface-requirement.slang) |
| C104: CompareLookupResultItems prefers a declaration in the type itself over an equally-applicable member contributed by an extension. | functional | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | [`tiebreak-non-extension-member-beats-extension-member.slang`](tiebreak-non-extension-member-beats-extension-member.slang) |
| C104: CompareLookupResultItems prefers an ordinary extension over a free-form extension whose target type is a constrained generic type parameter. | functional | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | [`tiebreak-ordinary-extension-beats-free-form-extension.slang`](tiebreak-ordinary-extension-beats-free-form-extension.slang) |
| C110: The [OverloadRank(N)] attribute breaks a tie that every earlier comparator step leaves equal, and the higher rank wins. | functional | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | [`tiebreak-overload-rank-attribute-wins.slang`](tiebreak-overload-rank-attribute-wins.slang) |
| C106: When exactly one of two otherwise-tied candidates carries ImplicitConversionModifier, that candidate wins instead of the pair being reported ambiguous. | functional | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | [`tiebreak-implicit-conversion-modifier-wins.slang`](tiebreak-implicit-conversion-modifier-wins.slang) |
| C107: compareOverloadCandidateSpecificity prefers the smaller getSpecializedParamCount, so a non-generic candidate beats a specialized generic one of equal cost. | functional | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | [`tiebreak-non-generic-beats-specialized-generic.slang`](tiebreak-non-generic-beats-specialized-generic.slang) |
| C109: getScopeRank prefers the declaration at the shorter scope distance from the call site when both non-generic candidates are otherwise equal. | functional | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | [`tiebreak-closer-scope-wins.slang`](tiebreak-closer-scope-wins.slang) |

## Untested claims

| Claim | Reason | Anchor | Why untested |
| --- | --- | --- | --- |
| C1, C2, C3, C5, C9: The `OverloadCandidate` `Flavor`, `Status` and `Flags` enumerations, the `GenericArgumentInferenceFailure::Kind` tag set and the `CoercionSite` enumeration are each named member by member. | internal-source-fact | [#concepts](../../../../design/name-resolution/overload-resolution.md#concepts) | These are C++ enumerator lists inside the checker. The behaviours the individual members select are covered by the per-step and per-`Kind` rows above, but the enumerations themselves have no surface a `.slang` file can name. |
| C7: `OverloadResolveContext::Mode` is `JustTrying`, which silently rejects bad candidates, or `ForReal`, which emits a diagnostic for each rejection. | internal-source-fact | [#concepts](../../../../design/name-resolution/overload-resolution.md#concepts) | The `JustTrying` half is observable only as "a rejected candidate produced no message", which is indistinguishable from the candidate not existing; the `ForReal` half is what every diagnostic test in this bundle already pins. |
| C8: `ConversionCost` is an `unsigned int` typedef whose `kConversionCost_*` levels sum across arguments. | internal-source-fact | [#concepts](../../../../design/name-resolution/overload-resolution.md#concepts) | The typedef is a C++ declaration. Its two thresholds are covered by the 900-ceiling and explicit-cast rows, and the summing behaviour by the accumulated-sum row. |
| C10: Every `GenericArgumentInferenceFailure` payload is trivially copyable and the default constructor `memset`s the whole object so a `kind`-switched copy does not trip `-Werror=maybe-uninitialized`. | internal-source-fact | [#concepts](../../../../design/name-resolution/overload-resolution.md#concepts) | A C++ object-layout and build-warning constraint with no consequence any compiled shader can observe. |
| C25, C26: `TryCheckOverloadCandidateConstraints` resolves defaults and witness arguments for an outermost generic through the `trySolveGenericArguments` fixpoint solver rather than a linear pass, and the solver's `solveCost` is deliberately not folded into `conversionCostSum`. | implementation-detail | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | Both statements are about which internal mechanism computes the same substitution. The doc says folding `solveCost` in would shift ranking, so the observable contract is precisely that nothing changes. |
| C31: `AddOverloadCandidateInner` removes every held entry the new candidate strictly beats, drops the new candidate when a held entry beats it, and asserts that the two outcomes never both happen. | implementation-detail | [#probe-phase-trycheckoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#probe-phase-trycheckoverloadcandidate) | Bookkeeping inside the running-winner set. The user-visible outcomes — a unique winner, or an ambiguity list — are covered by the comparator and ambiguity rows above. |
| C38: Each candidate-adding helper accepts a `baseCost` that is added to the candidate's accumulated cost, and today the only nontrivial one is what `inferGenericArguments` reports for inferred generic arguments. | implementation-detail | [#probe-phase-where-candidates-come-from](../../../../design/name-resolution/overload-resolution.md#probe-phase-where-candidates-come-from) | Every user-reachable entry point passes `kConversionCost_None`, so no pair of candidates a `.slang` file can write differs by `baseCost` alone. |
| C41: Every generic-inference-failure arm also emits a `Diagnostics::GenericSignatureTried` note rendered by `ASTPrinter::getDeclSignatureString`. | implementation-detail | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | The note accompanies the primary error the inference-failure tests already pin under `non-exhaustive`; asserting it would pin printed signature text rather than a resolution outcome. |
| C45: A `Flavor::UnspecializedGeneric` candidate never reaches the AST-construction switch because its `GenericArgumentInferenceFailed` status is handled by the early error path. | implementation-detail | [#finalize-phase-completeoverloadcandidate](../../../../design/name-resolution/overload-resolution.md#finalize-phase-completeoverloadcandidate) | A statement about which branch is not taken. Its observable consequence is the focused inference diagnostic, which the finalize rows above already cover. |
| C51: `canConvertImplicitly` allows anything cheaper than `kConversionCost_GeneralConversion` (900) and rejects anything at or above it. | implementation-detail | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | The doc itself records that the predicate is never called from `slang-check-overload.cpp` and serves generic constraint solving instead, so overload ranking shows no boundary at 900. |
| C53: `kConversionCost_GenericParamUpcast` is 1 — up-cast through a generic parameter. | implementation-detail | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | No arrangement of user-written overloads separates the up-cast from the surrounding generic-parameter binding cost, so the level cannot be ranked against a neighbouring one. |
| C57, C58, C71, C88: `kConversionCost_MatrixLayout` (5), `kConversionCost_GetRef` (5), `kConversionCost_FailedOptionalConstraint` (150) and `kConversionCost_LValueCast` (800) name conversions the table does not tie to a user-level construct. | implementation-detail | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | The table gives a one-phrase meaning with no Slang spelling for any of them, so there is no pair of overloads to rank; recorded as a `## Doc gaps observed` row. |
| C63: `kConversionCost_MutablePtrToConstPtr` is 20 — mutable pointer to const pointer. | implementation-detail | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | Unreachable, not merely untested: the constant has no reference anywhere in `source/` outside its own definition in `slang-ast-support-types.h`, so nothing charges this level. That is also why `Ptr<int>` to `Ptr<int, Access::Read>` is a plain type mismatch offered as an explicit cast rather than a costed implicit conversion. |
| C70: `kConversionCost_PtrToVoidPtr` is 150 — `T*` to `void*`. | implementation-detail | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | Slang has no user-writable void-pointer parameter spelling that can be placed opposite a competing overload. |
| C87: `kConversionCost_ScalarToCoopVector` is 1, additive when promoting a scalar to a cooperative vector. | gpu-cooperative | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | Unreachable, not merely untested: like `kConversionCost_MutablePtrToConstPtr`, the constant has no reference anywhere in `source/` outside its own definition, so no call pays this level regardless of target capability. |
| C89, C90: `kConversionCost_TypeCoercionConstraint` is 1000 and `kConversionCost_TypeCoercionConstraintPlusScalarToVector` is 1002. | implementation-detail | [#conversion-costs](../../../../design/name-resolution/overload-resolution.md#conversion-costs) | Both sit above the 900 implicit ceiling and are contributed by a `where U(T)` constraint rather than by an argument, so no pair of overloads differs by them alone. |
| C94: Because parameter-group coercion funnels into the dereference path, a user-declared initializer that takes a parameter-group type is never considered by the conversion search. | implementation-detail | [#conversions-that-do-not-have-their-own-cost-level](../../../../design/name-resolution/overload-resolution.md#conversions-that-do-not-have-their-own-cost-level) | The doc records this as a `TODO` describing a conversion that cannot be reached, so there is no successful call to observe and no diagnostic that names the omission. |
| C99: The guard above `AddTypeOverloadCandidates` fast-rejects coercing a `GenericTypeParamDeclBase` decl-ref to a non-`bool` scalar at a non-explicit coercion site, while `bool` and `DeclRefType` scalars stay on the search path. | implementation-detail | [#short-circuiting-a-doomed-conversion-search](../../../../design/name-resolution/overload-resolution.md#short-circuiting-a-doomed-conversion-search) | The doc states outright that this "is a pure performance guard: it changes no resolution outcome, only how long a doomed search takes", so there is no difference for a test to assert. |
| C100: Comparator step 1 prefers the candidate with the higher `Status`, so an `Applicable` candidate always beats an `ArityChecked` one. | implementation-detail | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | Every positive test in the bundle relies on it implicitly, but a candidate that fails an earlier filter step also loses the cost comparison, so no source arrangement isolates the status step from the steps that follow. |
| C103, C108: Comparator step 3 prefers a non-`extern` declaration over an `extern` one, and step 6 `getExportRank` fires only when the left candidate carries `ExternModifier` and the right carries `HLSLExportModifier`, then prefers the `extern` one. | needs-multi-file-test | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | `export` / `extern` are module-system primitives and each file here is compiled standalone, so no single-file source can put an `export` and an `extern` declaration of one name into the same candidate set. A two-file test importing the `export` half would verify both. |
| C105: Comparator step 3 also prefers any declaration over a module declaration and the more derived interface when both candidates are interface requirements, and returns "equal" outright when either candidate is a generic callable. | implementation-detail | [#tie-breaking-comparator](../../../../design/name-resolution/overload-resolution.md#tie-breaking-comparator) | A module declaration is never a callable candidate from user source, and the more-derived-interface preference needs two interface requirements to survive to the comparator, which the concrete-member preference collapses first. |
| C112: Lookup deliberately leaves duplicate `LookupResult` items in place, and collapsing them is this page's job. | out-of-bundle | [#relationship-to-lookup](../../../../design/name-resolution/overload-resolution.md#relationship-to-lookup) | The absence of `LookupResult`-level deduplication is the sibling `design/name-resolution/lookup` bundle's surface; this bundle covers only the comparator step that collapses the duplicates. |
| C113: `context.bestCandidates` can hold the same declaration more than once, so the no-applicable reporting path dedups by rendered signature string rather than by `Decl*`. | implementation-detail | [#relationship-to-lookup](../../../../design/name-resolution/overload-resolution.md#relationship-to-lookup) | The claim is about the note list's dedup key. Two specializations of one generic would have to reach the same failing call site along distinct lookup paths, and the resulting note text is not stable enough to pin. |
| C115, C116: `TryCheckOverloadCandidateConstraints` short-circuits on the `IsPartiallyAppliedGeneric` flag, and `PartiallyAppliedGenericExpr` stores `baseGenericDeclRef` plus `providedOrdinaryArgs` while witness arguments are formed later. | internal-source-fact | [#partial-generic-application](../../../../design/name-resolution/overload-resolution.md#partial-generic-application) | Both are statements about a node's fields and about a check being skipped; the observable outcome — a later invocation solving the remaining arguments — is covered by the partial-application rows above. |
| C118, C120: The parser turns `a + b` into an `InvokeExpr` whose `functionExpr` is a `VarExpr` naming the operator, and `BuiltinOperatorExpr` stores only a resolved `BuiltinOperationKind` plus its operands, with `arity` distinguishing prefix `-` (`Neg`) from binary `-` (`Sub`). | internal-source-fact | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | Both describe checked-AST node shapes. No directive in this bundle prints the AST, and the resolved kinds are observable only through the result types the fast-path rows already pin. |
| C128: The fast path declines the short-circuiting `&&` / `\|\|`, which `convertToLogicOperatorExpr` has already handled. | out-of-bundle | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | The user-visible consequence is short-circuit evaluation, which `design/ast-reference/expressions` already covers with `logic-and-short-circuit.slang` and `logic-or-short-circuit.slang`. |
| C134, C135: There is no operator-resolution cache at `source_commit` — `TypeCheckingCache` holds only `conversionCostCache` — and the leftover `ResolvedOperatorOverload` struct must not be read as documentation of current behavior. | internal-source-fact | [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | A removed cache and a dead C++ declaration; neither changes any resolution outcome a shader can observe. |
| C143: A `[mutating]` member operator applied to an immutable base is rejected by `TryCheckOverloadCandidateDirections`, which tests `context.baseExpr->type.isLeftValue`. | implementation-detail | [#the-general-path](../../../../design/name-resolution/overload-resolution.md#the-general-path) | User-declared infix operators cannot be members at all, so the only member operators are `operator()` and `__subscript`; the mutating-`this` rule itself is pinned by the mutating-method test above. |
| C145, C149: Tied candidates are listed as `Candidate` notes capped at 10 with a trailing `MoreOverloadCandidates` note, and the no-applicable report sorts candidates by `status` with source location as tie-breaker, dedups by rendered signature and counts only unique candidates in the trailing "N more". | implementation-detail | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | Note-list formatting rather than a resolution outcome; the diagnostic runner matches notes by position and message text, not by list shape, ordering or length. |
| C151: The `GenericArityMismatch` inference-failure kind maps to `Diagnostics::GenericSpecializationArityMismatch` — "wrong number of arguments in call to generic function". | implementation-detail | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | Every explicit generic-argument-list arity error reachable from single-file source is caught earlier — as "too many arguments to call" by the arity step, or by the generic-argument-list arity diagnostic — so this arm of the switch is shadowed. |
| C160: Scope-distance and overload-rank tie-breaking are skipped when at least one candidate is `Generic` or `UnspecializedGeneric`, while cost and specificity still apply. | implementation-detail | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | The specificity step already prefers the non-generic candidate whenever a generic is in the set, so removing the scope step from the comparison changes no outcome a single-file test can distinguish. |
| C163: Leaving a `PartiallyAppliedGenericExpr` residual unresolved is a correctness-invariant violation rather than a feature. | implementation-detail | [#edge-cases-and-failure-modes](../../../../design/name-resolution/overload-resolution.md#edge-cases-and-failure-modes) | A statement about an invariant the resolver maintains, not a behavior with a user-visible consequence; the doc forwards downstream handling to the AST-to-IR page. |

## Doc gaps observed

| Anchor | Kind | Gap | Suggested addition |
| --- | --- | --- | --- |
| [#the-builtin-operator-fast-path](../../../../design/name-resolution/overload-resolution.md#the-builtin-operator-fast-path) | drift-from-source | The section says `isGLSLOperatorScope` is true when `-allow-glsl` is set or the `glsl` module is in scope. The checker now uses the resolved GLSL source language or an explicit `glsl` import; deprecated `-allow-glsl` reaches that state only indirectly by selecting GLSL and emits a warning. | Describe resolved GLSL source and explicit `import glsl;` as the two operator-scope inputs. Mark `-allow-glsl` as deprecated and warn readers not to combine it with the explicit import. |

## Sibling-bundle overlap

[`docs/generated/tests/design/name-resolution/lookup/`](../lookup/README.md)
covers how the **candidate set** is built. This bundle covers how the resolver
narrows that set to a winner or to a structured ambiguity error. Claims
deliberately left to the sibling bundle:

- container-level overload accumulation, and the deliberate absence of
  cross-path `LookupResult` deduplication (C112);
- the inheritance walk that produces an inherited member as a candidate;
- transparent-member resolution and the breadcrumb chain's construction (this
  bundle only observes the chain being _replayed_ by
  `CompleteOverloadCandidate`).

[`docs/generated/tests/design/name-resolution/visibility/`](../visibility/README.md)
owns the `isDeclVisibleFromScope` rule itself; this bundle keeps only the one
test that shows the visibility filter running as a probe-phase step.

[`docs/generated/tests/design/ast-reference/expressions/`](../../ast-reference/expressions/README.md)
owns short-circuit evaluation of `&&` / `||`, which is the observable
consequence of C128.

## Deviation from `_prompt.md`

`_prompt.md` names a target of 15-25 tests, and the manifest's
`size_cap_files` is 70. Following the claim-driven rule that test count is an
output rather than a target, this bundle has 90 tests for 163 enumerated
claims. The overflow is the conversion-cost table: `_claims.md` §2 requires one
test per row of an enumeration the doc spells out, and the table has 40 rows.
Twenty-nine of the 90 tests are `DIAGNOSTIC_TEST` (32 percent), above the
prompt's 30 percent floor.
