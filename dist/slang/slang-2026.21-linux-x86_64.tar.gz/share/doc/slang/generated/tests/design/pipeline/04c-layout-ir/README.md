---
generated: true
model: claude-opus-5[1m]
generated_at: 2026-08-13T00:00:00+00:00
source_commit: c0e5ca5c55ff5ea6b210ac9418bac04728cc45e0
watched_paths_digest: be46cf0446effe4bf1b5fad8f17e307f84771e0991ee455ef7fcdbe0196ff3ff
source_doc: docs/generated/design/pipeline/04c-layout-ir.md
source_doc_digest: da9cda313002a3dcb389bcc82b9ad03eacafd2d3870e49b402a5804722d3eeb1
warning: "Auto-generated. May drift from source. Do not edit by hand."
---

# Tests for design/pipeline/04c-layout-ir

## Intent

This bundle exercises
[`docs/generated/design/pipeline/04c-layout-ir.md`](../../../../design/pipeline/04c-layout-ir.md),
which covers two coupled stages: the **parameter-binding pass** that
computes a target's `ProgramLayout`, and the **layout IR module** that
transcribes that `ProgramLayout` into `IRLayoutDecoration`s on stub
globals and entry-point functions.

The two halves need different observation points, so the bundle uses two
test families.

**Binding-decision tests** observe the emitted target code directly,
because a binding number, register space or descriptor set is visible in
HLSL `register(...)`, SPIR-V `OpDecorate ... Binding/DescriptorSet`, GLSL
`layout(binding=, set=)` and WGSL `@binding/@group`. These cover the
explicit-reservation ordering, the `vk::binding`-on-entry-point-parameter
target gate, the input-attachment-index space exemption, the bindless
descriptor-heap placement, and the diagnostics that abort binding.

**Layout-IR-shape tests** use
`-target <T> -dump-ir -o - -entry main -stage compute`. The layout
module is never dumped under a header of its own; its effects appear once
link merges it into the post-link IR, so these tests pin `CHECK-NOT`
patterns to the pre-link `### LOWER-TO-IR:` block and positive `CHECK`
patterns to the first post-link block. That block is matched as
<code>### AFTER &#123;&#123;[A-Za-z0-9_]+&#125;&#125;:</code> rather than
by pass name, because the claim is about the earliest post-link snapshot
and not about any particular pass: which pass runs first there changes as
passes are gated on `RequiredLoweringPassSet` flags and skipped when the
module holds nothing for them to do. Only the _structure_ of the
layout instructions is asserted (`varLayout(`, `offset(`,
`structTypeLayout(`, `parameterGroupTypeLayout(`, `EntryPointLayout(`,
`[layout(%N)]`); the numeric operands inside them are per-target by
design and are never pinned.

Target fan-out follows the claim: layout-IR construction itself is
exercised on all seven text-emit targets (`spirv-asm`, `hlsl`, `glsl`,
`metal`, `wgsl`, `cuda`, `cpp`), while a claim that is gated on the
target — such as `vk::binding` on an entry-point parameter — is split
into an honored-target test and an ignored-target test so both sides of
the gate are pinned. Claims about caches, obfuscation and internal
assertions are recorded under `## Untested claims`.

## Claims

Ground-truth enumeration of the source doc's testable claims, grouped by
its own headings. Every claim below appears in exactly one of the two
tables that follow. Because this page documents a compiler *phase*, the
list splits into two kinds of statement: **user-observable** claims — a
binding number, a descriptor set, a diagnostic code, or a layout
instruction that shows up in emitted text or in `-dump-ir` output — and
**internal-source facts** about the order of the binding stages, the C++
helper that owns a decision, and the private cache the result lands in.
The second kind is not reachable from any `//TEST` directive: the stages
run in one call and only their combined result is emitted, so a stage's
*effect* is observable while its *position* is not. Those claims are
classified in `## Untested claims` rather than tested.

**`## Parameter binding: producing the ProgramLayout`**

1. `createIRModuleForLayout` is a transcription step: every binding number, register space, and byte offset it writes into IR was already decided by parameter binding.
2. Stage 1 builds the `sharedContext.parameters` list and the `programLayout->entryPoints` array, treating entry points much like global parameters.
3. Stage 2 honors `register` / `vk::binding` / `layout(binding=)` on *global* parameters, recording them in the used-range sets before anything is auto-allocated.
4. Stage 3 reserves explicit `vk::binding`s that appear on entry-point parameters.
5. Stage 4 decides whether descriptor set 0 must be reserved for implicitly-placed parameters.
6. Stage 5 claims the first unused space for the default space / constant buffer.
7. Stage 6 auto-allocates every resource kind that is not already placed.
8. Stage 7 places the bindless descriptor heap only when the target implies `CapabilityName::descriptor_handle`.
9. The heap scan starts from the requested `-bindless-space-index` and moves upward to the first space not in `usedSpaces`.
10. When the chosen space is not the requested one and the option was given explicitly, binding warns `39012`, "requested bindless space index '~requested' is unavailable, using the next available index '~available'".
11. `programLayout->bindlessSpaceIndex` is set to the space actually chosen either way.
12. `usedSpaces` is populated only by `markSpaceUsed` and `allocateUnusedSpaces`, and is what the bindless-heap and default-space logic consult.
13. The per-space used-range sets track occupied index ranges *within* a space and drive overlap diagnostics; recording a range does not mark the space used.

**`### Explicit vk::binding on entry-point parameters`**

14. `[[vk::binding(binding, set)]]` on an entry-point parameter is honored exactly on the targets for which `isKhronosTarget(target) || isWGPUTarget(target)` holds, i.e. SPIR-V/GLSL and WGSL.
15. In the worked example the annotated parameter is decorated `Binding 3` / `DescriptorSet 1` for `-target spirv`.
16. For `-target hlsl` the same request is dropped and the parameter is placed positionally as `register(t0)`.
17. An entry-point `vk::binding` can position only `DescriptorTableSlot` for a plain resource, buffer or sampler, and `SubElementRegisterSpace` for a whole-space parameter such as a `ParameterBlock`.
18. The annotation positions a single resource info, preferring the descriptor slot; the register-space case applies only when there is no descriptor slot.
19. The attribute is honored only when the parameter's type actually consumes a descriptor-shaped resource.
20. A `SubpassInput` consumes two kinds at once, so the reservation covers both the descriptor slot and the `InputAttachmentIndex`.
21. Entry points carrying an honored annotation take the per-parameter completion path; all others take the ordinary aggregate path.
22. One entry point can mix explicitly- and implicitly-bound parameters: the explicit reservations are re-seeded and the implicit ones get real bindings allocated from the global context.
23. An entry point whose parameters are all explicitly bound no longer forces a default set.
24. `Diagnostics::UnhandledModOnEntryPointParameter` — warning `38010`, "modifier on entry point parameter is unsupported" — still fires for annotations binding cannot honor, for example a plain varying scalar.

**`### vk::input_attachment_index and descriptor-space occupancy`**

25. A Vulkan input-attachment index lowers to `OpDecorateInputAttachmentIndex` only, never `OpDecorateDescriptorSet`.
26. `addExplicitParameterBinding` skips `markSpaceUsed` for `InputAttachmentIndex`.
27. The index range is still recorded in the used-range set, so two parameters asking for the same attachment index still draw `Diagnostics::ParameterBindingsOverlap` — warning `39001`, "explicit binding overlap".
28. `doesEntryPointParameterResourceNeedDefaultSpace` returns `false` for `InputAttachmentIndex` alongside `PushConstantBuffer`, `RegisterSpace`, `SubElementRegisterSpace`, `VaryingInput`, `VaryingOutput`, `HitAttributes` and `RayPayload`; every other kind falls through the `default:` arm and returns `true`.
29. The observable effect is that a `SubpassInput` entry-point parameter no longer causes descriptor set 0 to be reported unavailable to the bindless descriptor heap.
30. `VaryingInput` / `VaryingOutput` (with `[[vk::location]]`) and `SpecializationConstant` (with `[[vk::constant_id]]`) reach the same branch with the same placeholder space 0 and share the latent pattern, but the guard was not widened to them.

**`### Diagnosed failures during binding`**

31. Parameter binding can fail with diagnostics rather than producing a `ProgramLayout`; `getOrCreateLayout` then returns `nullptr` and no layout IR module is built.
32. A null return from `getRayPayloadParameterRules` / `getCallablePayloadParameterRules` / `getHitAttributesParameterRules` is diagnosed as error `39032`, "the current compilation target does not support ray tracing entry point parameters for the '~stage' stage", instead of being dereferenced.
33. The Metal, CPU and LLVM layout-rules families return `nullptr` from all three accessors.
34. The CUDA family returns `nullptr` from `getCallablePayloadParameterRules` alone.
35. The SPIR-V/GLSL, HLSL/DXIL and WGSL families supply all three accessors.
36. The worked `miss` example compiles for `-target spirv` but is rejected with error `39032` for `-target metal` and `-target cpp`.
37. This is a target-limitation diagnostic, distinct from the pre-existing stage-limitation diagnostics, because callable and hit stages do support these parameters on SPIR-V, HLSL and GLSL.

**`## Why this module exists`**

38. Layout is target-specific: the same source program can have different binding numbers, register spaces, byte offsets and entry-point parameter mappings for D3D11, D3D12, Vulkan, Metal, WebGPU and CUDA.
39. Carrying layout information inside an IR module makes it queryable by the reflection API and consumable by the linker.
40. Keeping it in a separate module avoids contaminating the per-translation-unit executable IR, which is cached on the `Module` and shared across all targets.

**`## When it is built`**

41. The layout module is built together with the `ProgramLayout` inside `getOrCreateLayout`, so any caller that asks for the program layout also pays for it.
42. `getOrCreateIRModuleForLayout` is a two-line wrapper that calls `getOrCreateLayout` and then returns the now-populated field.
43. Nothing is built when binding failed, and the absence is directly observable: a `-dump-ir` run prints the `### LOWER-TO-IR:` block and then stops, with no `EntryPointLayout(`, `structTypeLayout(` or `[layout(` anywhere in the output.
44. `createIRModuleForLayout` returns the cached module immediately when one exists, asserts `m_layout` is non-null, and otherwise bails out with `nullptr`.
45. The layout module does not run the pre-link mandatory optimization sequence; it is consumed by reflection and by `linkIR`, which adds it to its module list so layout-decorated global symbols participate in linking.

**`## Per-global-parameter steps`**

46. Step 1 materializes a stub `IRGlobalVar`, producing an `[import(...)]` stub when no definition is present, and fails with `SLANG_UNEXPECTED("unhandled value flavor")` if materialize returns null.
47. Step 2 lowers the variable layout to an `IRVarLayout` encoding binding, space and byte offset.
48. Step 3 attaches the `IRLayoutDecoration` that makes the layout queryable on the stub.
49. Step 4 records the stub in the global type-layout builder, feeding the module-level `IRStructTypeLayout`.
50. The loop runs once per field of the global struct layout.

**`## Global-scope type layout`**

51. After the loop the function builds an `IRStructTypeLayout` for the whole global scope.
52. When the global scope is wrapped in a parameter group (a constant buffer or push-constant block), the module's layout decoration is an `IRParameterGroupTypeLayout` rather than the raw struct layout.
53. The parameter-group builder sets the container var layout, the element var layout and the offset element type layout.
54. The resulting global-scope var layout is attached to the module instance via `addLayoutDecoration(irModule->getModuleInst(), ...)`.

**`## Per-entry-point steps`**

55. Step 1 skips entry points with no AST, because the layout-IR module cannot synthesize a stub for a deserialized entry point.
56. Step 2 skips unspecialized generic entry points, which do not yet have a concrete layout.
57. Step 3 lowers the function type to an `IRFuncType`.
58. Step 4 materializes the stub `IRFunc` skeleton, usually `[import(...)]`.
59. Step 5 attaches an import decoration when the stub has no linkage, wiring it to its real implementation by mangled name.
60. Step 6 forwards capability atoms in `[_spirv_1_0, latestSpirvAtom]` or `[metallib_2_3, latestMetalAtom]`, so the layout module advertises the SPIR-V / Metal capability set per entry point.
61. Step 7 lowers the entry-point layout to an `IREntryPointLayout` that encodes parameter bindings and stage.
62. Step 8 attaches the `IRLayoutDecoration` that the reflection API and the linker query.

**`## Optional obfuscation pass`**

63. `shouldObfuscateCode()` gates a strip of name hints and source locations followed by a DCE run with `keepExportsAlive` and `keepLayoutsAlive` set.
64. The layout module sets `stripSourceLocs = true` where the executable-module block sets it to `false`, and sets `shouldStripNameHints = true` unconditionally inside the gate.
65. Nothing about this block is separately observable from outside the compiler; with `-obfuscate` both modules lose their name hints together.

**`## What this module is not`**

66. It is not the per-module executable IR produced by `generateIRForTranslationUnit`.
67. It is not the executable IR optimized by `linkAndOptimizeIR`, though `linkIR` does pull it into its symbol set so its layout decorations are visible during linking.
68. It has no function bodies for user-defined functions; entry-point `IRFunc` instances are stubs that only anchor layout and capability decorations.
69. No mandatory optimization passes run there: the `constructSSA` -> SCCP -> CFG-simplify -> peephole -> DCE -> early-inlining sequence does not execute on this module.

**`## Cache and reuse`**

70. The result is cached on `TargetProgram::m_irModuleForLayout`, so a second `getOrCreateIRModuleForLayout` call for the same `TargetProgram` returns the same module without re-running construction.
71. Different `TargetProgram` instances build independent layout IR modules, so a session compiling for both D3D12 and Vulkan holds two of them.
72. `createIRModuleForLayout` is `private` and its only in-tree caller is `getOrCreateLayout`.
73. `getExistingIRModuleForLayout()` peeks at the cache without forcing construction and returns `nullptr` when nothing has been built yet.

**`## Caveats and gotchas`**

74. Materialize failure is a hard error: an unhandled value flavor for a global parameter aborts with `SLANG_UNEXPECTED`.
75. `m_layout` must be set — a debug build asserts and a release build returns `nullptr`.
76. Capability decorations are SPIR-V- and Metal-only; the decoration is `IRRequireCapabilityAtomDecoration`, printed by the IR dumper as `[requireCapabilityAtom(...)]`, and there is no observation point at which it can be attributed to the *layout* module.
77. `buildMangledNameToGlobalInstMap` runs unconditionally, so consumers always get a usable mangled-name index.
78. The entry-point loop asserts that the entry-point declaration is a `FuncDecl` before reading its inferred capability requirements.

**`## Option gates`**

79. `-obfuscate` enables the strip + DCE block at the end of `createIRModuleForLayout` and is also passed to the `SharedIRGenContext` constructor.
80. `-bindless-space-index <index>` requests a specific descriptor space for the bindless descriptor heap, honored only if that space is not already in `usedSpaces`.
81. Other options in the compiler-options header, including `shouldIncludeSourceInDebugInfo()`, belong to debug information and codegen and have no effect on either parameter binding or the layout IR module.

**`## Manifest coverage`**

82. The page's manifest `watched_paths` do not cover six paths the page must cite, and those six should be added to the manifest entry.

## Functional coverage

| Claim                                                                                                                                                                               | Intent     | Anchor                                                                                                                                                           | Tests                                                                                                                                  |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| A family that supplies ray-payload rules binds the miss payload instead of diagnosing it, so the same shader that fails on Metal compiles for SPIR-V and for CUDA.                   | functional | [#diagnosed-failures-during-binding](../../../../design/pipeline/04c-layout-ir.md#diagnosed-failures-during-binding)                                             | [`raytracing-miss-payload-accepted-where-rules-exist.slang`](raytracing-miss-payload-accepted-where-rules-exist.slang)                 |
| A ray-tracing entry-point parameter on a target with no layout rules for it is diagnosed with error E39032 instead of crashing.                                                     | negative   | [#diagnosed-failures-during-binding](../../../../design/pipeline/04c-layout-ir.md#diagnosed-failures-during-binding)                                             | [`raytracing-entry-point-param-unsupported-target-diagnostic.slang`](raytracing-entry-point-param-unsupported-target-diagnostic.slang) |
| A target whose layout-rules family has no callable-payload rules rejects a callable entry-point payload with `E39032` naming the callable stage. | negative   | [#diagnosed-failures-during-binding](../../../../design/pipeline/04c-layout-ir.md#diagnosed-failures-during-binding) | [`raytracing-callable-payload-rejected-on-metal.slang`](raytracing-callable-payload-rejected-on-metal.slang) |
| The CPU layout-rules family supplies no ray-payload rules either, so the same miss payload that compiles for SPIR-V is rejected with E39032 for -target cpp.                        | negative   | [#diagnosed-failures-during-binding](../../../../design/pipeline/04c-layout-ir.md#diagnosed-failures-during-binding)                                             | [`raytracing-miss-payload-rejected-on-cpp.slang`](raytracing-miss-payload-rejected-on-cpp.slang)                                       |
| A vk::binding on a whole-space entry-point parameter such as a ParameterBlock positions the register space, so every member lands in the requested set.                             | boundary   | [#explicit-vkbinding-on-entry-point-parameters](../../../../design/pipeline/04c-layout-ir.md#explicit-vkbinding-on-entry-point-parameters)                       | [`vk-binding-entry-point-param-parameter-block-whole-space.slang`](vk-binding-entry-point-param-parameter-block-whole-space.slang)     |
| A vk::binding on an entry-point parameter that the target cannot honor is reported with the unsupported-entry-point-parameter-modifier warning E38010.                              | negative   | [#explicit-vkbinding-on-entry-point-parameters](../../../../design/pipeline/04c-layout-ir.md#explicit-vkbinding-on-entry-point-parameters)                       | [`vk-binding-entry-point-param-ignored-warning.slang`](vk-binding-entry-point-param-ignored-warning.slang)                             |
| An entry point whose parameters are all explicitly vk::binding-bound no longer forces a default descriptor space, leaving set 0 available.                                          | functional | [#explicit-vkbinding-on-entry-point-parameters](../../../../design/pipeline/04c-layout-ir.md#explicit-vkbinding-on-entry-point-parameters)                       | [`all-vk-bound-entry-point-params-need-no-default-space.slang`](all-vk-bound-entry-point-params-need-no-default-space.slang)           |
| An explicit vk::binding on an entry-point parameter is honored on the Khronos targets (SPIR-V, GLSL) and on WGSL.                                                                   | functional | [#explicit-vkbinding-on-entry-point-parameters](../../../../design/pipeline/04c-layout-ir.md#explicit-vkbinding-on-entry-point-parameters)                       | [`vk-binding-entry-point-param-honored-on-khronos-and-wgpu.slang`](vk-binding-entry-point-param-honored-on-khronos-and-wgpu.slang)     |
| Even on a target that honors the attribute, a vk::binding placed on a parameter type that consumes no descriptor-shaped resource is reported as ignored.                            | boundary   | [#explicit-vkbinding-on-entry-point-parameters](../../../../design/pipeline/04c-layout-ir.md#explicit-vkbinding-on-entry-point-parameters)                       | [`vk-binding-on-varying-param-warns-even-on-khronos.slang`](vk-binding-on-varying-param-warns-even-on-khronos.slang)                   |
| On targets outside the Khronos/WGPU gate the vk::binding on an entry-point parameter is ignored and the parameter is placed positionally instead.                                   | negative   | [#explicit-vkbinding-on-entry-point-parameters](../../../../design/pipeline/04c-layout-ir.md#explicit-vkbinding-on-entry-point-parameters)                       | [`vk-binding-entry-point-param-ignored-on-other-targets.slang`](vk-binding-entry-point-param-ignored-on-other-targets.slang)           |
| One entry point can mix an explicitly vk::binding-bound parameter with an implicitly bound one; the explicit reservation is kept and the implicit parameter is allocated around it. | boundary   | [#explicit-vkbinding-on-entry-point-parameters](../../../../design/pipeline/04c-layout-ir.md#explicit-vkbinding-on-entry-point-parameters)                       | [`vk-binding-entry-point-param-mixed-explicit-and-implicit.slang`](vk-binding-entry-point-param-mixed-explicit-and-implicit.slang)     |
| On CUDA and C++ the global scope is itself a parameter group, so the module-level layout is a parameterGroupTypeLayout even without a user-written cbuffer.                         | boundary   | [#global-scope-type-layout](../../../../design/pipeline/04c-layout-ir.md#global-scope-type-layout)                                                               | [`global-scope-wrapped-in-parameter-group-on-cuda-and-cpp.slang`](global-scope-wrapped-in-parameter-group-on-cuda-and-cpp.slang)       |
| The global-scope var layout is attached to the module instance itself, appearing as a top-level varLayout instruction rather than a let-bound one.                                  | functional | [#global-scope-type-layout](../../../../design/pipeline/04c-layout-ir.md#global-scope-type-layout)                                                               | [`module-instance-has-toplevel-varlayout.slang`](module-instance-has-toplevel-varlayout.slang)                                         |
| When the global scope is wrapped in a parameter group such as a cbuffer, the module's layout is a parameterGroupTypeLayout rather than a bare structTypeLayout.                     | functional | [#global-scope-type-layout](../../../../design/pipeline/04c-layout-ir.md#global-scope-type-layout)                                                               | [`cbuffer-produces-parameter-group-type-layout.slang`](cbuffer-produces-parameter-group-type-layout.slang)                             |
| With no parameter-group wrapping, the global scope's type layout is a plain structTypeLayout instruction built after the per-global-parameter loop.                                 | functional | [#global-scope-type-layout](../../../../design/pipeline/04c-layout-ir.md#global-scope-type-layout)                                                               | [`global-scope-struct-type-layout-built.slang`](global-scope-struct-type-layout-built.slang)                                           |
| The -bindless-space-index option places the system bindless resource heap in the requested descriptor space when that space is unused.                                              | functional | [#option-gates](../../../../design/pipeline/04c-layout-ir.md#option-gates)                                                                                       | [`bindless-space-index-request-honored.slang`](bindless-space-index-request-honored.slang)                                             |
| The third explicit-binding spelling the stage-2 row names, GLSL layout(binding=), is reserved on a global parameter before automatic allocation.                                     | functional | [#parameter-binding-producing-the-programlayout](../../../../design/pipeline/04c-layout-ir.md#parameter-binding-producing-the-programlayout)                     | [`explicit-global-glsl-layout-binding-reserved.slang`](explicit-global-glsl-layout-binding-reserved.slang)                             |
| An explicit HLSL register annotation on a global parameter is likewise reserved before automatic allocation of the remaining globals.                                               | functional | [#parameter-binding-producing-the-programlayout](../../../../design/pipeline/04c-layout-ir.md#parameter-binding-producing-the-programlayout)                     | [`explicit-global-register-reserved-before-auto-allocation.slang`](explicit-global-register-reserved-before-auto-allocation.slang)     |
| Explicit vk::binding annotations on global parameters are reserved before any automatic allocation, so an earlier unannotated global skips the reserved slot.                       | functional | [#parameter-binding-producing-the-programlayout](../../../../design/pipeline/04c-layout-ir.md#parameter-binding-producing-the-programlayout)                     | [`explicit-global-vk-binding-reserved-before-auto-allocation.slang`](explicit-global-vk-binding-reserved-before-auto-allocation.slang) |
| When the requested bindless space is already occupied the binding pass warns with E39012 and scans upward for the first unused space.                                               | negative   | [#parameter-binding-producing-the-programlayout](../../../../design/pipeline/04c-layout-ir.md#parameter-binding-producing-the-programlayout)                     | [`bindless-space-index-unavailable-warning.slang`](bindless-space-index-unavailable-warning.slang)                                     |
| Lowering the entry-point layout produces an EntryPointLayout instruction with two operands, one varLayout for the parameters and one for the result.                                | functional | [#per-entry-point-steps](../../../../design/pipeline/04c-layout-ir.md#per-entry-point-steps)                                                                     | [`entry-point-layout-has-param-and-result-operands.slang`](entry-point-layout-has-param-and-result-operands.slang)                     |
| The final per-entry-point step attaches an IRLayoutDecoration to the stub entry-point function, observable as a [layout(%N)] on func %main.                                         | functional | [#per-entry-point-steps](../../../../design/pipeline/04c-layout-ir.md#per-entry-point-steps)                                                                     | [`entry-point-func-gets-layout-decoration.slang`](entry-point-func-gets-layout-decoration.slang)                                       |
| The layout-module entry-point stub is wired to the executable-IR definition by mangled name, so after link the entry point carries a matching export decoration.                    | functional | [#per-entry-point-steps](../../../../design/pipeline/04c-layout-ir.md#per-entry-point-steps)                                                                     | [`entry-point-func-keeps-export-decoration.slang`](entry-point-func-keeps-export-decoration.slang)                                     |
| The lowered entry-point layout encodes both the pipeline stage and each parameter's system-value semantic.                                                                          | functional | [#per-entry-point-steps](../../../../design/pipeline/04c-layout-ir.md#per-entry-point-steps)                                                                     | [`entry-point-layout-encodes-stage-and-semantic.slang`](entry-point-layout-encodes-stage-and-semantic.slang)                           |
| Each per-global-parameter step attaches an IRLayoutDecoration to the stub IRGlobalVar, observable as a [layout(%N)] on the global_param in the first post-link IR snapshot.         | functional | [#per-global-parameter-steps](../../../../design/pipeline/04c-layout-ir.md#per-global-parameter-steps)                                                           | [`global-param-gets-layout-decoration.slang`](global-param-gets-layout-decoration.slang)                                               |
| Lowering a global parameter's variable layout produces a varLayout instruction that carries an offset operand encoding the per-target placement.                                    | functional | [#per-global-parameter-steps](../../../../design/pipeline/04c-layout-ir.md#per-global-parameter-steps)                                                           | [`global-param-varlayout-has-offset-operand.slang`](global-param-varlayout-has-offset-operand.slang)                                   |
| Recording each stub global in the global type-layout builder yields one structFieldLayout entry naming that stub variable and its lowered varLayout.                                | functional | [#per-global-parameter-steps](../../../../design/pipeline/04c-layout-ir.md#per-global-parameter-steps)                                                           | [`per-global-struct-field-layout-entries.slang`](per-global-struct-field-layout-entries.slang)                                         |
| The per-global-parameter loop runs once per field of the global struct layout, so two distinct global parameters produce two distinct structFieldLayout entries.                    | boundary   | [#per-global-parameter-steps](../../../../design/pipeline/04c-layout-ir.md#per-global-parameter-steps)                                                           | [`multiple-globals-each-get-layout.slang`](multiple-globals-each-get-layout.slang)                                                     |
| An input-attachment index does not occupy a descriptor set, so a SubpassInput entry-point parameter leaves set 0 available to the bindless descriptor heap.                         | functional | [#vkinput_attachment_index-and-descriptor-space-occupancy](../../../../design/pipeline/04c-layout-ir.md#vkinput_attachment_index-and-descriptor-space-occupancy) | [`input-attachment-index-leaves-descriptor-space-zero-free.slang`](input-attachment-index-leaves-descriptor-space-zero-free.slang)     |
| Skipping the descriptor-space reservation for an input-attachment index does not weaken overlap detection: two parameters requesting the same index are still diagnosed.            | negative   | [#vkinput_attachment_index-and-descriptor-space-occupancy](../../../../design/pipeline/04c-layout-ir.md#vkinput_attachment_index-and-descriptor-space-occupancy) | [`input-attachment-index-overlap-still-diagnosed.slang`](input-attachment-index-overlap-still-diagnosed.slang)                         |
| Linking pulls the existing layout module into its symbol set, so layout decorations absent pre-link become visible on the linked global and entry point.                            | functional | [#what-this-module-is-not](../../../../design/pipeline/04c-layout-ir.md#what-this-module-is-not)                                                                 | [`layout-module-merged-by-linkir.slang`](layout-module-merged-by-linkir.slang)                                                         |
| The pre-link executable IR carries no layout decorations and no layout instructions, keeping the per-module IR free of target-specific layout.                                      | negative   | [#what-this-module-is-not](../../../../design/pipeline/04c-layout-ir.md#what-this-module-is-not)                                                                 | [`lower-to-ir-block-has-no-layout-decorations.slang`](lower-to-ir-block-has-no-layout-decorations.slang)                               |
| When parameter binding fails with an error no layout IR module is built, so the dump contains no layout instructions after the pre-link block.                                      | negative   | [#when-it-is-built](../../../../design/pipeline/04c-layout-ir.md#when-it-is-built)                                                                               | [`no-layout-ir-module-when-binding-fails.slang`](no-layout-ir-module-when-binding-fails.slang)                                         |
| A layout IR module is built per target, so the same source yields layout instructions and layout decorations on every text-emit target.                                             | functional | [#why-this-module-exists](../../../../design/pipeline/04c-layout-ir.md#why-this-module-exists)                                                                   | [`layout-ir-module-built-for-every-target.slang`](layout-ir-module-built-for-every-target.slang)                                       |

## Untested claims

| Claim                                                                                                                                                                                                                                           | Reason                | Anchor                                                                                                                                                           | Why untested                                                                                                                                                                                                           |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `createIRModuleForLayout` is `private`, and its only in-tree caller is `getOrCreateLayout`.                                                                                                                                                     | internal-source-fact  | [#cache-and-reuse](../../../../design/pipeline/04c-layout-ir.md#cache-and-reuse)                                                                                 | A C++ access-specifier fact. Every CLI compile reaches construction through the one public path, so no input distinguishes a private constructor from a public one.                                                    |
| The result is cached on `TargetProgram::m_irModuleForLayout`; a second `getOrCreateIRModuleForLayout` call for the same `TargetProgram` returns the same module without re-running construction.                                                | internal-source-fact  | [#cache-and-reuse](../../../../design/pipeline/04c-layout-ir.md#cache-and-reuse)                                                                                 | Cache hit and cache miss produce identical compiler output, so no `//TEST` directive can distinguish them. A C++ unit test holding a `TargetProgram` and comparing two returned pointers is what would verify it.      |
| Different `TargetProgram` instances build independent layout IR modules, so a session compiling for both D3D12 and Vulkan holds two independent layout modules in memory.                                                                       | needs-unit-test       | [#cache-and-reuse](../../../../design/pipeline/04c-layout-ir.md#cache-and-reuse)                                                                                 | One `slangc` invocation creates one `TargetProgram`; simultaneous in-memory independence needs a host program that adds two targets to a session and inspects both layout modules.                                     |
| `getExistingIRModuleForLayout()` peeks at the cache without forcing construction and returns `nullptr` when nothing has been built yet.                                                                                                         | needs-unit-test       | [#cache-and-reuse](../../../../design/pipeline/04c-layout-ir.md#cache-and-reuse)                                                                                 | A C++ accessor with no CLI surface; a unit test calling it before and after `getOrCreateLayout` would verify the two return values.                                                                                    |
| `buildMangledNameToGlobalInstMap` runs unconditionally at the end of construction so consumers always get a usable mangled-name index.                                                                                                          | internal-source-fact  | [#caveats-and-gotchas](../../../../design/pipeline/04c-layout-ir.md#caveats-and-gotchas)                                                                         | The index is an in-memory side table; neither `-dump-ir` nor any emitted text reveals whether it was built.                                                                                                            |
| Capability decorations are forwarded onto layout-module entry points only for SPIR-V and Metal; HLSL, WGSL and CUDA layout-module entry points carry none.                                                                                      | implementation-detail | [#caveats-and-gotchas](../../../../design/pipeline/04c-layout-ir.md#caveats-and-gotchas)                                                                         | The layout module's capability decorations merge with the executable module's and are rewritten by post-link passes before the first dumped snapshot, so no dump surface attributes a decoration to the layout module. |
| Materialize failure is a hard error: an unhandled value flavor for a global parameter aborts with `SLANG_UNEXPECTED`.                                                                                                                           | internal-source-fact  | [#caveats-and-gotchas](../../../../design/pipeline/04c-layout-ir.md#caveats-and-gotchas)                                                                         | The doc describes the trigger as a corrupted or out-of-sync per-module IR cache; no `.slang` source can put the compiler in that state.                                                                                |
| The entry-point loop asserts that the entry-point declaration is a `FuncDecl` before reading its inferred capability requirements.                                                                                                              | internal-source-fact  | [#caveats-and-gotchas](../../../../design/pipeline/04c-layout-ir.md#caveats-and-gotchas)                                                                         | Front-end checking rejects non-function entry points long before binding, so the assertion is unreachable from source.                                                                                                 |
| `m_layout` must be set: a debug build asserts and a release build returns `nullptr` for a caller that reaches construction with no program layout.                                                                                              | internal-source-fact  | [#caveats-and-gotchas](../../../../design/pipeline/04c-layout-ir.md#caveats-and-gotchas)                                                                         | Construction is `private` and only reachable through `getOrCreateLayout`, which always sets `m_layout` first; no CLI input bypasses that path.                                                                         |
| The SPIR-V/GLSL, HLSL/DXIL and WGSL layout-rules families all supply the three ray-tracing parameter-rule accessors.                                                                                                                            | unsupported-on-target | [#diagnosed-failures-during-binding](../../../../design/pipeline/04c-layout-ir.md#diagnosed-failures-during-binding)                                             | The SPIR-V and HLSL halves are covered by the accepting test; the wgsl half is not reachable, because `-target wgsl -stage miss` aborts with E99997 "unsupported stage" before parameter binding runs. See the doc-gap row below. |
| The parameter-group builder sets the container var layout, the element var layout and the offset element type layout on the lowered `IRParameterGroupTypeLayout`.                                                                               | internal-source-fact  | [#global-scope-type-layout](../../../../design/pipeline/04c-layout-ir.md#global-scope-type-layout)                                                               | The three setter calls are C++ builder steps; the dumped `parameterGroupTypeLayout(` instruction that the existing cbuffer test pins is their combined result, and no dump surface separates the three.                |
| Six paths the page cites are absent from its manifest `watched_paths` and should be added to the manifest entry.                                                                                                                                | process-doc           | [#manifest-coverage](../../../../design/pipeline/04c-layout-ir.md#manifest-coverage)                                                                             | A statement about this documentation set's own regeneration bookkeeping, not about compiler behaviour.                                                                                                                 |
| `-obfuscate` enables the strip + DCE block at the end of construction and is also passed to the `SharedIRGenContext` constructor.                                                                                                               | implementation-detail | [#option-gates](../../../../design/pipeline/04c-layout-ir.md#option-gates)                                                                                       | The doc states in the obfuscation section that nothing about that block is separately observable for the layout module, and the executable module's own strip block is gated on the same option.                       |
| Other options in the compiler-options header, including `shouldIncludeSourceInDebugInfo()`, have no effect on parameter binding or on the layout IR module.                                                                                     | implementation-detail | [#option-gates](../../../../design/pipeline/04c-layout-ir.md#option-gates)                                                                                       | A claim of no-effect over an open-ended option set; a test could only sample it, and a sample that shows no change is indistinguishable from an option that was never read.                                            |
| Step 3 lowers the entry-point function type to an `IRFuncType` and step 4 materializes the stub `IRFunc` skeleton, usually as an `[import(...)]`.                                                                                               | internal-source-fact  | [#per-entry-point-steps](../../../../design/pipeline/04c-layout-ir.md#per-entry-point-steps)                                                                     | The stub is replaced by the executable-side definition during link, so every dumped snapshot already shows the real function; the intermediate `IRFuncType` and skeleton are never printed.                            |
| Step 1 materializes a stub `IRGlobalVar`, producing an `[import(...)]` stub when no definition is present, and aborts with `SLANG_UNEXPECTED("unhandled value flavor")` when materialize returns null.                                          | internal-source-fact  | [#per-global-parameter-steps](../../../../design/pipeline/04c-layout-ir.md#per-global-parameter-steps)                                                           | The stub's import linkage is erased by link before any snapshot is printed, and the abort path is the corrupted-cache failure mode covered by the materialize-failure row below.                                       |
| The ordered stage list's internal structure: layout-IR construction is a pure transcription of decisions binding already made, stage 1 builds the parameter list and entry-point array, stage 5 claims the first unused space, `usedSpaces` is populated only by `markSpaceUsed` / `allocateUnusedSpaces`, `programLayout->bindlessSpaceIndex` records the chosen space, the annotation positions a single preferred resource info, and an honored annotation selects the per-parameter completion path. | internal-source-fact  | [#parameter-binding-producing-the-programlayout](../../../../design/pipeline/04c-layout-ir.md#parameter-binding-producing-the-programlayout)                     | All seven are statements about which helper owns a decision and in what order, inside one `generateParameterBindings` call. Only the combined result is emitted, so a stage's effect is observable while its position and owner are not.                     |
| Stage 7 places the bindless descriptor heap only when the target implies `CapabilityName::descriptor_handle`.                                                                                                                                   | implementation-detail | [#parameter-binding-producing-the-programlayout](../../../../design/pipeline/04c-layout-ir.md#parameter-binding-producing-the-programlayout)                     | On a target without the capability the `DescriptorHandle` source that would demand a heap is rejected during capability checking, so the heap's absence cannot be attributed to the stage-7 gate rather than to the earlier rejection.                        |
| The pre-existing stage-limitation diagnostics (for example the `in`-only-callable case) are distinct from the target-limitation error E39032, because callable and hit stages do support ray-tracing parameters on SPIR-V, HLSL and GLSL.       | out-of-bundle         | [#diagnosed-failures-during-binding](../../../../design/pipeline/04c-layout-ir.md#diagnosed-failures-during-binding)                                             | The stage-limitation diagnostics belong to entry-point semantic checking rather than to parameter binding; they are the `design/pipeline/03-semantic-check` bundle's surface, and this bundle covers only E39032.      |
| A Vulkan input-attachment index lowers to `OpDecorateInputAttachmentIndex` only, never `OpDecorateDescriptorSet`.                                                                                                                               | internal-source-fact  | [#vkinput_attachment_index-and-descriptor-space-occupancy](../../../../design/pipeline/04c-layout-ir.md#vkinput_attachment_index-and-descriptor-space-occupancy) | The sentence is about the `InputAttachmentIndex` resource kind, not about the parameter: an unannotated `SubpassInput<float4>` observably does carry `OpDecorate ... DescriptorSet 0` from its separate descriptor-slot reservation. See the doc-gap row below. |
| The other non-descriptor-space kinds — `PushConstantBuffer`, `RegisterSpace`, `VaryingInput`, `VaryingOutput`, `HitAttributes` and `RayPayload` — also return `false` from `doesEntryPointParameterResourceNeedDefaultSpace`.                    | implementation-detail | [#vkinput_attachment_index-and-descriptor-space-occupancy](../../../../design/pipeline/04c-layout-ir.md#vkinput_attachment_index-and-descriptor-space-occupancy) | `InputAttachmentIndex` and `SubElementRegisterSpace` are covered; the remaining kinds have no honored entry-point-parameter surface — `[[vk::push_constant]]` there is reported unsupported with warning E38010, so the branch is not reachable from source. |
| `VaryingInput`/`VaryingOutput` (with `[[vk::location]]`) and `SpecializationConstant` (with `[[vk::constant_id]]`) reach the same branch with the same placeholder space 0 and share the latent pattern, but the guard was not widened to them. | implementation-detail | [#vkinput_attachment_index-and-descriptor-space-occupancy](../../../../design/pipeline/04c-layout-ir.md#vkinput_attachment_index-and-descriptor-space-occupancy) | The doc describes an unfixed latent condition, not a behaviour the compiler currently guarantees; a test would pin the present-day symptom of a known-pending change rather than a claim.                              |
| The layout module sets `stripSourceLocs = true` where the executable-module block sets it to `false`, and sets `shouldStripNameHints = true` unconditionally inside the gate.                                                                   | internal-source-fact  | [#optional-obfuscation-pass](../../../../design/pipeline/04c-layout-ir.md#optional-obfuscation-pass)                                                             | Two field assignments inside a gate the doc itself describes as not separately observable; with `-obfuscate` both modules are stripped together, so no output attributes a difference to the layout module's settings.  |
| The obfuscation gate strips name hints and source locations from the layout module and then dead-code-eliminates it while keeping exports and layouts alive.                                                                                    | implementation-detail | [#optional-obfuscation-pass](../../../../design/pipeline/04c-layout-ir.md#optional-obfuscation-pass)                                                             | The doc names no user-observable consequence for the layout module specifically; whatever is observable under obfuscation is dominated by the executable module's own strip block. See the doc-gap row below.          |
| Deserialized entry points have no AST-level information, so the layout module skips them and synthesizes no stub.                                                                                                                               | needs-multi-file-test | [#per-entry-point-steps](../../../../design/pipeline/04c-layout-ir.md#per-entry-point-steps)                                                                     | Reaching the skip requires an entry point loaded from a precompiled `.slang-module` rather than from source, i.e. a two-file compile-then-import test.                                                                 |
| Generic entry points without specialization arguments are skipped because they do not yet have a concrete layout.                                                                                                                               | implementation-detail | [#per-entry-point-steps](../../../../design/pipeline/04c-layout-ir.md#per-entry-point-steps)                                                                     | The skip removes a stub that would otherwise be present; with no entry point emitted at all for such a program, the dump difference is indistinguishable from the entry point simply not existing.                     |
| No mandatory optimization passes run on the layout module: the SSA / SCCP / CFG-simplify / peephole / DCE / early-inlining sequence does not execute there.                                                                                     | implementation-detail | [#what-this-module-is-not](../../../../design/pipeline/04c-layout-ir.md#what-this-module-is-not)                                                                 | The layout module's functions are bodyless stubs, so an optimization sequence that did run would have nothing to change; the absence of an effect is indistinguishable from the absence of work.                       |
| Carrying layout information inside an IR module makes it queryable by the reflection API and consumable by the linker, rather than requiring callers to hold a parallel `ProgramLayout` alongside every IR module.                               | needs-unit-test       | [#why-this-module-exists](../../../../design/pipeline/04c-layout-ir.md#why-this-module-exists)                                                                   | The reflection half needs a host program that walks `IComponentType::getLayout()` and compares it against the decorated symbols; `slangc` exposes no directive that reads layout back through the reflection API.      |
| The layout module is built inside `getOrCreateLayout` so every layout caller pays for it, `getOrCreateIRModuleForLayout` is a two-line wrapper over that call, and construction returns the cached module (or `nullptr` for a cleared layout) before doing any work. | internal-source-fact  | [#when-it-is-built](../../../../design/pipeline/04c-layout-ir.md#when-it-is-built)                                                                               | Three statements about call structure inside a single compile. Every path a `slangc` invocation can take goes through `getOrCreateLayout` exactly once, so the wrapper, the cache check and the null bail produce identical output. |
| Entry-point `IRFunc` instances in the layout module have no bodies; they exist only to anchor layout and capability decorations.                                                                                                                | implementation-detail | [#what-this-module-is-not](../../../../design/pipeline/04c-layout-ir.md#what-this-module-is-not)                                                                 | After link the stub is replaced by the executable-side definition, so every dumped snapshot shows the function with a body; the bodyless intermediate is never printed.                                                |

## Doc gaps observed

(none) — no gaps remain open against this bundle's source document.

Every gap previously listed here was fixed on the documentation side and
recorded in `docs/generated/design/_meta/doc-gap-state.json`; the answers
are now in the source document itself.

The eight gap rows this bundle previously recorded have all been filled by
the current revision of the page (the E39012 / E39001 / E38010 codes, the
`-bindless-space-index` and `-obfuscate` CLI spellings, the `miss`-payload
and `vk::binding` worked examples, the `-dump-ir` observability note, and
the `[requireCapabilityAtom(...)]` dumper spelling are all present now), so
they are retired here. The rows below are what re-reading the filled page
against the compiler turned up.
